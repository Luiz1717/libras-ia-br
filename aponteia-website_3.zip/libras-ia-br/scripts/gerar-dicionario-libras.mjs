#!/usr/bin/env node
/**
 * Gera src/data/libras-dictionary.json a partir de content/sinais-libras.csv
 *
 * Esse script existe para que a equipe de conteúdo (instrutores de Libras,
 * revisores) consiga adicionar ou corrigir sinais editando uma planilha
 * (CSV, exportável do Google Sheets/Excel), sem precisar mexer em código.
 *
 * Uso:
 *   node scripts/gerar-dicionario-libras.mjs
 *   (ou "npm run libras:gerar")
 *
 * Colunas esperadas no CSV (nessa ordem, com cabeçalho):
 *   id,palavra,categoria,descricao,exemplo,regiao,videoUrl,posterUrl,status,atualizadoEm
 *
 * - id: identificador único, curto, sem espaços (ex.: "computador").
 * - videoUrl / posterUrl: podem ficar vazios enquanto o vídeo não foi
 *   gravado — o site mostra automaticamente um estado "vídeo pendente".
 * - status: "revisado" (já validado por pessoa surda/linguista de Libras)
 *   ou "em_revisao" (ainda não validado).
 */
import { parse } from "csv-parse/sync";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CSV_PATH = path.join(__dirname, "..", "content", "sinais-libras.csv");
const OUT_PATH = path.join(__dirname, "..", "src", "data", "libras-dictionary.json");

const REQUIRED_COLUMNS = ["id", "palavra", "categoria", "descricao", "exemplo"];
const VALID_STATUS = new Set(["revisado", "em_revisao"]);

function fail(message) {
  console.error(`\n❌ ${message}\n`);
  process.exit(1);
}

function main() {
  let raw;
  try {
    raw = readFileSync(CSV_PATH, "utf-8");
  } catch {
    fail(`Não encontrei o arquivo ${CSV_PATH}. Crie o CSV a partir do modelo antes de rodar este script.`);
  }

  const rows = parse(raw, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  });

  const seenIds = new Set();
  const errors = [];

  const signs = rows.map((row, index) => {
    const lineNumber = index + 2; // +1 pelo cabeçalho, +1 porque index começa em 0

    for (const col of REQUIRED_COLUMNS) {
      if (!row[col]) {
        errors.push(`Linha ${lineNumber}: coluna obrigatória "${col}" está vazia.`);
      }
    }

    if (row.id) {
      if (seenIds.has(row.id)) {
        errors.push(`Linha ${lineNumber}: id "${row.id}" duplicado.`);
      }
      seenIds.add(row.id);
    }

    if (row.status && !VALID_STATUS.has(row.status)) {
      errors.push(
        `Linha ${lineNumber}: status "${row.status}" inválido (use "revisado" ou "em_revisao").`
      );
    }

    return {
      id: row.id,
      word: row.palavra,
      category: row.categoria,
      description: row.descricao,
      example: row.exemplo,
      region: row.regiao || undefined,
      videoUrl: row.videoUrl || undefined,
      posterUrl: row.posterUrl || undefined,
      status: VALID_STATUS.has(row.status) ? row.status : "em_revisao",
      updatedAt: row.atualizadoEm || undefined,
    };
  });

  if (errors.length > 0) {
    console.error(`\n❌ Encontrei ${errors.length} problema(s) no CSV:\n`);
    errors.forEach((e) => console.error(`  - ${e}`));
    console.error("\nCorrija o CSV e rode o script novamente.\n");
    process.exit(1);
  }

  mkdirSync(path.dirname(OUT_PATH), { recursive: true });
  writeFileSync(OUT_PATH, JSON.stringify(signs, null, 2) + "\n", "utf-8");

  const comVideo = signs.filter((s) => s.videoUrl).length;
  console.log(`✅ ${signs.length} sinais gerados em ${path.relative(process.cwd(), OUT_PATH)}`);
  console.log(`   ${comVideo} com vídeo publicado, ${signs.length - comVideo} com vídeo pendente.`);
}

main();
