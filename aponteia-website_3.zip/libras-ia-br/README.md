# AponteIA — IA para acessibilidade e Libras

Plataforma brasileira de tecnologia assistiva com Inteligência Artificial, criada com foco
na comunidade surda brasileira: Libras, legendas automáticas, fala para texto, texto para
voz, OCR e um assistente de IA para explicar e resumir conteúdos.

Este repositório contém o **MVP 1 + partes dos MVP 2 e 3** do roadmap descrito no briefing
original (interface completa, autenticação, dashboard, IA, voz↔texto, OCR, legendas,
histórico, acessibilidade e recursos de Libras), implementado como um frontend completo e
funcional, com um backend simulado (mockado) — pronto para ser conectado a serviços reais.

## Stack técnica

- **Next.js 16** (App Router) + **React 19** + **TypeScript**
- **Tailwind CSS v4**
- **tesseract.js** para OCR real, executado no navegador
- **Web Speech API** (nativa do navegador) para fala → texto e texto → voz
- **lucide-react** para ícones
- Nenhum backend real nesta versão — ver seção "O que é real vs. simulado" abaixo

## Como rodar

```bash
npm install
npm run dev     # ambiente de desenvolvimento em http://localhost:3000
npm run build   # build de produção
npm run start   # servir o build de produção
npm run lint    # checagem de lint
```

Requer Node.js 20.9+.

## O que é real vs. simulado nesta versão

O objetivo desta entrega é fornecer uma base de frontend completa, navegável e com o
máximo de funcionalidade real possível **sem depender de infraestrutura de servidor**, já
que nenhuma chave de API de IA foi fornecida. Especificamente:

**Funciona de verdade, direto no navegador do usuário:**
- Fala → Texto (`/voz-para-texto`) e ditado por voz no chat de IA — via `SpeechRecognition`
  do navegador (melhor suporte no Chrome).
- Texto → Voz (`/texto-para-voz`) e "Ouvir" em várias telas — via `speechSynthesis`.
- OCR (`/ocr`) — via `tesseract.js`, rodando inteiramente no navegador (a primeira execução
  baixa o modelo de idioma português via CDN).
- Acesso à câmera para captura de foto (OCR) e para o painel experimental de Libras → Texto
  — via `getUserMedia`.
- Geração e exportação real de arquivos `.srt` e `.vtt` na ferramenta de Legendas, a partir
  do conteúdo editado pelo usuário.
- Configurações de acessibilidade (tamanho de texto, contraste, tema, animações, densidade)
  — aplicadas via CSS custom properties e persistidas em `localStorage`.
- Autenticação, histórico e perfil — funcionam de ponta a ponta, mas os dados ficam salvos
  apenas em `localStorage` do navegador (não há backend nem banco de dados reais).
- Dicionário de Libras (`/libras` → "Dicionário") — a estrutura de dados, busca, filtro por
  categoria e paginação já suportam vídeos reais e centenas/milhares de sinais, gerados a
  partir de uma planilha (ver "Como adicionar sinais reais" abaixo). Hoje só 3 sinais têm
  vídeo de exemplo (placeholder) para demonstrar o mecanismo — os demais mostram o estado
  "vídeo pendente", como ficariam antes de serem gravados.
- Painel administrativo de sinais (`/admin/libras`) — cadastro de sinais com upload de
  vídeo, geração automática de miniatura, edição/exclusão e exportação de um pacote
  (.zip com vídeos + CSV) pronto para publicar. Os dados ficam salvos de verdade num banco
  local do navegador (IndexedDB) — ver "Alternativa mais rápida" abaixo.

**Simulado (mock), com a interface e os estados de carregamento já prontos para o real:**
- Respostas do assistente de IA (`/ia`) e as ferramentas de estudo em `/educacao`
  (resumir, explicar, gerar perguntas/flashcards) — toda a lógica de IA passa por uma única
  camada em `src/lib/ai.ts`, para que baste trocar as funções ali por chamadas a um provedor
  real (Anthropic, OpenAI etc.) sem alterar nenhuma página.
- Transcrição automática de vídeo em Legendas — gera legendas de exemplo distribuídas ao
  longo da duração real do vídeo enviado, para que o fluxo de edição/exportação possa ser
  testado de ponta a ponta.
- Reconhecimento de Libras por câmera e a pré-visualização de Português → Libras — a
  interface, os avisos de "experimental" e o indicador de confiança estão prontos; a
  inferência real exigiria um modelo de visão computacional especializado (ver seção
  "Sobre Libras e IA" abaixo).
- Exportação de áudio (.mp3) em Texto → Voz — a reprodução funciona de verdade; o download
  do arquivo de áudio depende de processamento em servidor.
- Painel administrativo (`/admin`) — métricas de exemplo, ainda sem conexão a dados reais
  (exceto os números da Biblioteca de Libras, que já refletem o dicionário real). A gestão
  de sinais em `/admin/libras` é funcional de verdade (ver acima), mas nenhuma das rotas
  `/admin/*` tem autenticação — não use em produção sem antes proteger o acesso.

## Arquitetura pensada para crescer

- `src/lib/ai.ts` — única camada de integração com IA. Trocar por chamadas reais aqui já
  atualiza todas as páginas que consomem IA (chat, resumos, explicações, perguntas,
  flashcards).
- `src/lib/auth.tsx` — contexto de autenticação mockado com a mesma assinatura que uma
  integração real (login, cadastro, login social, logout) teria.
- `src/lib/history.ts` — camada de histórico; hoje usa `localStorage`, mas a assinatura das
  funções já está pronta para ser trocada por chamadas de API.
- `src/lib/accessibility.tsx` — contexto de acessibilidade global, usado por toda a
  aplicação.
- Cada ferramenta vive em sua própria rota (`/voz-para-texto`, `/texto-para-voz`, `/ocr`,
  `/legendas`, `/libras`, `/ia`, `/educacao`...), com um componente de servidor para
  metadata/SEO e um componente de cliente para a interatividade — facilitando reaproveitar
  a mesma lógica de UI em uma futura versão mobile (React Native/Capacitor), já que a
  camada de dados está isolada em `src/lib`.

## PWA

- `src/app/manifest.ts` gera o manifest da aplicação.
- `public/sw.js` implementa um service worker simples com cache e página offline
  (`public/offline.html`).
- Um banner de instalação (`InstallPwaBanner`) aparece quando o navegador permite instalar
  o app na tela inicial.
- O service worker só é registrado em produção (`npm run build && npm run start`).

## Acessibilidade

- Navegação por teclado, foco visível, `skip link`, landmarks semânticos, labels em todos
  os campos, textos alternativos e mensagens de erro associadas aos campos via
  `aria-describedby`.
- Central de acessibilidade em `/acessibilidade`: tamanho de texto, alto contraste, tema
  claro/escuro/sistema, redução de animações e densidade de interface — tudo aplicado
  imediatamente e persistido.
- Nenhuma informação importante depende exclusivamente de som ou cor.

## Sobre Libras e IA

Libras é uma língua natural, com gramática, estrutura espacial e expressões não manuais
próprias — não é uma tradução palavra por palavra do português, e nenhuma IA hoje a traduz
com perfeição. Por isso, todas as funcionalidades relacionadas a Libras nesta plataforma:

- são claramente identificadas como **experimentais**;
- exibem um nível de confiança estimado e o aviso "resultado estimado pela IA";
- foram desenhadas para, numa implementação real, serem desenvolvidas e avaliadas com a
  participação de pessoas fluentes em Libras e especialistas — nunca para substituir um
  intérprete humano em contextos importantes (saúde, jurídico, emergências).

## Como adicionar sinais reais ao dicionário (escala até milhares)

O dicionário de Libras (`/libras` → aba "Dicionário") **não** guarda mais os sinais direto
no código. Ele é gerado a partir de uma planilha, para que uma equipe de conteúdo (instrutores
surdos, revisores linguistas) consiga adicionar ou corrigir sinais sem precisar programar —
e para aguentar centenas ou milhares de sinais sem o site ficar pesado.

**Fluxo de trabalho:**

1. Grave os vídeos dos sinais seguindo um padrão único (mesmo fundo, enquadramento da
   cintura para cima com o rosto visível, ~2-4s por sinal) e envie cada vídeo para um
   armazenamento com URL pública — por exemplo Cloudflare R2, AWS S3, Cloudflare Stream ou
   Mux. **Não** coloque os vídeos dentro da pasta `public/` do projeto: com centenas ou
   milhares de arquivos, isso deixaria o repositório e o deploy extremamente pesados.
2. Edite a planilha `content/sinais-libras.csv` (abre normalmente no Excel/Google Sheets —
   exporte de volta como CSV depois de editar). Cada linha é um sinal, com as colunas:
   `id, palavra, categoria, descricao, exemplo, regiao, videoUrl, posterUrl, status,
   atualizadoEm`. Pode deixar `videoUrl` vazio enquanto o vídeo ainda não foi gravado — o
   site já mostra automaticamente um estado de "vídeo pendente" nesse caso.
3. Rode `npm run libras:gerar` (ou apenas `npm run dev` / `npm run build`, que já rodam
   esse passo automaticamente antes). O script lê o CSV, valida os dados e gera
   `src/data/libras-dictionary.json`, que é o que a página realmente usa.
4. O campo `status` (`revisado` ou `em_revisao`) controla o selo mostrado em cada sinal —
   use `revisado` só depois que pelo menos uma pessoa surda/linguista de Libras validar
   aquele sinal especificamente.

### Alternativa mais rápida: painel administrativo (`/admin/libras`)

Editar o CSV linha a linha funciona bem para poucos sinais, mas cansa rápido quando o
volume cresce. Para isso existe um painel visual em **`/admin/libras`** (link também
disponível dentro de `/admin`) que substitui os passos 1 e 2 acima:

1. No painel, preencha o formulário do sinal (palavra, categoria, descrição, exemplo,
   status) e escolha o arquivo de vídeo direto do seu computador. O identificador (`id`) é
   gerado automaticamente a partir da palavra, e uma miniatura do vídeo é capturada
   sozinha para usar como pôster.
2. Cada sinal salvo fica guardado num banco de dados local do navegador (IndexedDB) — ou
   seja, é persistência de verdade, só que roda no seu navegador em vez de um servidor.
   Você pode fechar a aba e voltar depois que os rascunhos continuam lá. Dá para
   visualizar, editar e excluir cada sinal na lista, e "Limpar tudo" apaga todos os
   rascunhos locais (não afeta o que já está publicado no site).
3. Quando terminar de cadastrar um lote, preencha a "URL base" (o endereço onde os vídeos
   vão ficar hospedados, ex.: `https://cdn.seusite.com/sinais`) e clique em **"Baixar
   pacote (.zip)"**. O pacote já vem com os vídeos, as miniaturas e um `sinais-libras.csv`
   pronto no formato certo — só falta subir os vídeos para o seu armazenamento (Cloudflare
   R2, S3 etc.) e substituir `content/sinais-libras.csv` no projeto pelo CSV baixado
   (ou usar o botão "Baixar apenas o CSV" se preferir só o texto). Depois é rodar
   `npm run libras:gerar` como no passo 3 acima.

Como é tudo local, o painel não tem login nem trava o acesso — em produção, proteja a rota
`/admin` (e `/admin/libras`) atrás de autenticação/rede interna antes de publicar o site,
já que hoje ela é só uma demonstração da interface.

A página do dicionário já tem paginação ("Carregar mais sinais") pensada para não travar
com uma base grande, e a busca/filtro por categoria funciona sobre o total, não só sobre o
que está visível na tela.

Se o catálogo crescer muito (na casa dos milhares) e a equipe for atualizar isso com
frequência, o próximo passo natural é trocar o CSV por uma planilha viva (Google
Sheets/Airtable) ou por um banco de dados real — a função `SIGN_LIBRARY` em
`src/lib/libras-data.ts` foi isolada exatamente para que essa troca não exija mudar as
páginas que a consomem.

## Roadmap (do briefing original)

- **MVP 1** (nesta entrega): Home, cadastro, login, dashboard, IA, Voz → Texto, Texto →
  Voz, OCR, histórico, acessibilidade.
- **MVP 2** (parcialmente nesta entrega): Vídeo → Legenda, exportação SRT/VTT, editor de
  legendas, resumos, ferramentas de documentos.
- **MVP 3** (parcialmente nesta entrega): biblioteca de Libras, Português → Libras,
  estrutura para vídeos/GIFs/avatar.
- **MVP 4** (planejado): Libras → Texto com visão computacional real, expressões faciais,
  contexto linguístico — pesquisa com especialistas e comunidade surda.
- **MVP 5** (planejado): conversação em tempo real, plataforma educacional completa, API
  pública, integrações institucionais, aplicativos Android e iOS.

## Próximos passos sugeridos para produção

1. Conectar `src/lib/ai.ts` a um provedor de IA real, mantendo a interface das funções.
2. Substituir os contextos de autenticação e histórico por um backend real (API + banco de
   dados), preservando as mesmas assinaturas de função.
3. Implementar processamento assíncrono real (fila) para vídeos e áudios longos.
4. Iniciar pesquisa e testes de reconhecimento de Libras com participação da comunidade
   surda e especialistas linguísticos.
5. Auditoria de segurança (rate limiting, validação de upload, sanitização) e de
   privacidade/LGPD antes de qualquer lançamento com dados reais de usuários.
