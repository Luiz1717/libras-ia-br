export type HistoryType =
  | "transcricao"
  | "legenda"
  | "conversa"
  | "documento"
  | "resumo"
  | "traducao"
  | "ocr";

export interface HistoryItem {
  id: string;
  type: HistoryType;
  title: string;
  preview: string;
  createdAt: string;
}

const STORAGE_KEY = "libras-ia:historico";

const TYPE_LABELS: Record<HistoryType, string> = {
  transcricao: "Transcrição",
  legenda: "Legenda",
  conversa: "Conversa com IA",
  documento: "Documento",
  resumo: "Resumo",
  traducao: "Tradução",
  ocr: "Leitura de imagem",
};

export function historyTypeLabel(type: HistoryType) {
  return TYPE_LABELS[type];
}

const SEED: HistoryItem[] = [
  {
    id: "seed-1",
    type: "transcricao",
    title: "Reunião de equipe — 14/08",
    preview: "Transcrição automática da reunião semanal com a equipe de produto.",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
  },
  {
    id: "seed-2",
    type: "legenda",
    title: "Aula de matemática — funções",
    preview: "Legenda gerada automaticamente (SRT) para vídeo de 12 minutos.",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
  },
  {
    id: "seed-3",
    type: "resumo",
    title: "Artigo sobre acessibilidade digital",
    preview: "Resumo com os principais pontos do artigo enviado em PDF.",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6).toISOString(),
  },
  {
    id: "seed-4",
    type: "ocr",
    title: "Boleto de energia elétrica",
    preview: "Texto reconhecido a partir de foto do documento.",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 9).toISOString(),
  },
];

function isBrowser() {
  return typeof window !== "undefined";
}

export function getHistory(): HistoryItem[] {
  if (!isBrowser()) return SEED;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED));
      return SEED;
    }
    return JSON.parse(raw);
  } catch {
    return SEED;
  }
}

export function addHistoryItem(item: Omit<HistoryItem, "id" | "createdAt">) {
  if (!isBrowser()) return;
  const items = getHistory();
  const next: HistoryItem = {
    ...item,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
  };
  const updated = [next, ...items];
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return next;
}

export function removeHistoryItem(id: string) {
  if (!isBrowser()) return;
  const updated = getHistory().filter((i) => i.id !== id);
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}

export function renameHistoryItem(id: string, title: string) {
  if (!isBrowser()) return;
  const updated = getHistory().map((i) => (i.id === id ? { ...i, title } : i));
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}
