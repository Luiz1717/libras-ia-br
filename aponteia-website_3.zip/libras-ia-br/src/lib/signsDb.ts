"use client";

/**
 * Banco de dados local (IndexedDB) para o painel administrativo de sinais
 * de Libras. Isso É um banco de dados de verdade — só que roda dentro do
 * navegador, não em um servidor. Serve como área de "rascunho": você
 * cadastra os sinais aqui (com vídeo e tudo), e depois exporta um pacote
 * pronto (vídeos + CSV) para publicar de verdade no site — ver
 * `/admin/libras` e o README, seção "Como adicionar sinais reais".
 *
 * Por que não salva direto no site? Porque o navegador não tem permissão
 * para escrever arquivos no projeto nem subir vídeos para um servidor sem
 * um backend configurado. Este banco local resolve a parte de "digitar e
 * organizar os dados uma vez só", sem perder nada ao fechar a aba.
 */
import { openDB, type DBSchema, type IDBPDatabase } from "idb";

export type DraftStatus = "revisado" | "em_revisao";

export interface SignDraft {
  id: string;
  word: string;
  category: string;
  description: string;
  example: string;
  region: string;
  status: DraftStatus;
  videoBlob?: Blob;
  videoName?: string;
  posterBlob?: Blob;
  posterName?: string;
  updatedAt: string;
}

interface SignsDbSchema extends DBSchema {
  sinais: {
    key: string;
    value: SignDraft;
  };
}

const DB_NAME = "aponteia-admin-libras";
const STORE = "sinais";

let dbPromise: Promise<IDBPDatabase<SignsDbSchema>> | null = null;

function getDb() {
  if (!dbPromise) {
    dbPromise = openDB<SignsDbSchema>(DB_NAME, 1, {
      upgrade(db) {
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: "id" });
        }
      },
    });
  }
  return dbPromise;
}

export async function listDrafts(): Promise<SignDraft[]> {
  const db = await getDb();
  const all = await db.getAll(STORE);
  return all.sort((a, b) => a.word.localeCompare(b.word, "pt-BR"));
}

export async function saveDraft(draft: SignDraft): Promise<void> {
  const db = await getDb();
  await db.put(STORE, draft);
}

export async function deleteDraft(id: string): Promise<void> {
  const db = await getDb();
  await db.delete(STORE, id);
}

export async function clearDrafts(): Promise<void> {
  const db = await getDb();
  await db.clear(STORE);
}

const DIACRITICS_REGEX = new RegExp("[̀-ͯ]", "g");

export function slugify(word: string): string {
  return word
    .normalize("NFD")
    .replace(DIACRITICS_REGEX, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}
