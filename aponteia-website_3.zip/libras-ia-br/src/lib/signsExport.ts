"use client";

import type { SignDraft } from "./signsDb";

function csvEscape(value: string): string {
  if (value.includes(",") || value.includes('"') || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

function extensionFromName(name: string | undefined, fallback: string) {
  if (!name) return fallback;
  const match = /\.([a-zA-Z0-9]+)$/.exec(name);
  return match ? match[1].toLowerCase() : fallback;
}

/**
 * Gera o conteúdo do CSV no mesmo formato lido por
 * scripts/gerar-dicionario-libras.mjs, já com videoUrl/posterUrl apontando
 * para onde os arquivos vão ficar depois de você subir o pacote exportado
 * para o seu armazenamento (ex.: Cloudflare R2, S3).
 */
export function buildCsv(drafts: SignDraft[], baseUrl: string): string {
  const header =
    "id,palavra,categoria,descricao,exemplo,regiao,videoUrl,posterUrl,status,atualizadoEm";
  const cleanBase = baseUrl.trim().replace(/\/$/, "");

  const rows = drafts.map((d) => {
    const videoExt = extensionFromName(d.videoName, "mp4");
    const videoUrl = d.videoBlob && cleanBase ? `${cleanBase}/${d.id}.${videoExt}` : "";
    const posterUrl = d.posterBlob && cleanBase ? `${cleanBase}/${d.id}.jpg` : "";

    return [
      d.id,
      d.word,
      d.category,
      d.description,
      d.example,
      d.region,
      videoUrl,
      posterUrl,
      d.status,
      d.updatedAt,
    ]
      .map((v) => csvEscape(v ?? ""))
      .join(",");
  });

  return [header, ...rows].join("\n") + "\n";
}

export async function buildExportZip(drafts: SignDraft[], baseUrl: string): Promise<Blob> {
  const JSZip = (await import("jszip")).default;
  const zip = new JSZip();

  zip.file("sinais-libras.csv", buildCsv(drafts, baseUrl));

  const videosFolder = zip.folder("videos");
  for (const draft of drafts) {
    if (draft.videoBlob) {
      const ext = extensionFromName(draft.videoName, "mp4");
      videosFolder?.file(`${draft.id}.${ext}`, draft.videoBlob);
    }
    if (draft.posterBlob) {
      videosFolder?.file(`${draft.id}.jpg`, draft.posterBlob);
    }
  }

  const leiame = `Como usar este pacote
======================

1. Suba todos os arquivos da pasta "videos" para o seu armazenamento de
   arquivos (ex.: Cloudflare R2, AWS S3, Cloudflare Stream, Mux) — o mesmo
   endereço base que você digitou no painel administrativo antes de
   exportar.
2. Copie o conteúdo de "sinais-libras.csv" para dentro de
   content/sinais-libras.csv no projeto (substituindo ou completando as
   linhas existentes).
3. Rode "npm run libras:gerar" (ou apenas "npm run dev" / "npm run build").
4. Os sinais aparecem no dicionário do site com o vídeo real.
`;
  zip.file("LEIA-ME.txt", leiame);

  return zip.generateAsync({ type: "blob" });
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/** Captura um frame do vídeo (em segundos) como imagem JPEG, para usar como miniatura. */
export function captureVideoFrame(file: File, atSeconds = 0.3): Promise<Blob | null> {
  return new Promise((resolve) => {
    const video = document.createElement("video");
    video.preload = "auto";
    video.muted = true;
    video.playsInline = true;
    const url = URL.createObjectURL(file);
    video.src = url;

    const cleanup = () => URL.revokeObjectURL(url);

    video.addEventListener("loadedmetadata", () => {
      video.currentTime = Math.min(atSeconds, Math.max(video.duration - 0.05, 0));
    });

    video.addEventListener("seeked", () => {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        cleanup();
        resolve(null);
        return;
      }
      ctx.drawImage(video, 0, 0);
      canvas.toBlob(
        (blob) => {
          cleanup();
          resolve(blob);
        },
        "image/jpeg",
        0.85
      );
    });

    video.addEventListener("error", () => {
      cleanup();
      resolve(null);
    });
  });
}
