"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

export type FontSize = "pequeno" | "normal" | "grande" | "muito-grande";
export type Contrast = "normal" | "alto";
export type ThemeMode = "claro" | "escuro" | "sistema";
export type MotionMode = "ativadas" | "reduzidas";
export type Density = "compacta" | "confortavel";

export interface AccessibilitySettings {
  fontSize: FontSize;
  contrast: Contrast;
  theme: ThemeMode;
  motion: MotionMode;
  density: Density;
}

const DEFAULT_SETTINGS: AccessibilitySettings = {
  fontSize: "normal",
  contrast: "normal",
  theme: "sistema",
  motion: "ativadas",
  density: "confortavel",
};

const FONT_SCALE: Record<FontSize, string> = {
  pequeno: "0.9",
  normal: "1",
  grande: "1.15",
  "muito-grande": "1.35",
};

const STORAGE_KEY = "libras-ia:acessibilidade";

interface AccessibilityContextValue {
  settings: AccessibilitySettings;
  setFontSize: (v: FontSize) => void;
  setContrast: (v: Contrast) => void;
  setTheme: (v: ThemeMode) => void;
  setMotion: (v: MotionMode) => void;
  setDensity: (v: Density) => void;
  resetSettings: () => void;
}

const AccessibilityContext = createContext<AccessibilityContextValue | null>(
  null
);

function applySettingsToDom(settings: AccessibilitySettings) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;

  root.style.setProperty("--font-scale", FONT_SCALE[settings.fontSize]);

  root.classList.toggle("contrast-high", settings.contrast === "alto");
  root.classList.toggle(
    "motion-reduced",
    settings.motion === "reduzidas" ||
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches
  );
  root.classList.toggle("density-compact", settings.density === "compacta");

  let isDark = false;
  if (settings.theme === "escuro") isDark = true;
  else if (settings.theme === "claro") isDark = false;
  else
    isDark =
      window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;

  root.classList.toggle("dark", isDark);
  root.setAttribute("data-theme", isDark ? "escuro" : "claro");
}

export function AccessibilityProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [settings, setSettings] = useState<AccessibilitySettings>(
    DEFAULT_SETTINGS
  );
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    // Lê preferências salvas apenas no cliente, depois da primeira renderização,
    // para que o HTML do servidor e a primeira renderização do cliente
    // continuem idênticos (evita erro de hidratação).
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setSettings({ ...DEFAULT_SETTINGS, ...parsed });
      }
    } catch {
      // ignore corrupted storage
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    applySettingsToDom(settings);
    if (hydrated) {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
      } catch {
        // ignore quota errors
      }
    }
  }, [settings, hydrated]);

  useEffect(() => {
    if (settings.theme !== "sistema") return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = () => applySettingsToDom(settings);
    mq.addEventListener?.("change", handler);
    return () => mq.removeEventListener?.("change", handler);
  }, [settings]);

  const setFontSize = useCallback(
    (v: FontSize) => setSettings((s) => ({ ...s, fontSize: v })),
    []
  );
  const setContrast = useCallback(
    (v: Contrast) => setSettings((s) => ({ ...s, contrast: v })),
    []
  );
  const setTheme = useCallback(
    (v: ThemeMode) => setSettings((s) => ({ ...s, theme: v })),
    []
  );
  const setMotion = useCallback(
    (v: MotionMode) => setSettings((s) => ({ ...s, motion: v })),
    []
  );
  const setDensity = useCallback(
    (v: Density) => setSettings((s) => ({ ...s, density: v })),
    []
  );
  const resetSettings = useCallback(() => setSettings(DEFAULT_SETTINGS), []);

  const value = useMemo(
    () => ({
      settings,
      setFontSize,
      setContrast,
      setTheme,
      setMotion,
      setDensity,
      resetSettings,
    }),
    [settings, setFontSize, setContrast, setTheme, setMotion, setDensity, resetSettings]
  );

  return (
    <AccessibilityContext.Provider value={value}>
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const ctx = useContext(AccessibilityContext);
  if (!ctx) {
    throw new Error(
      "useAccessibility deve ser usado dentro de AccessibilityProvider"
    );
  }
  return ctx;
}
