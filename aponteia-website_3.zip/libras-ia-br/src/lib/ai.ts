/**
 * Camada de integração com IA.
 *
 * Esta é a única parte do código que deve ser trocada quando um provedor de
 * IA real (Anthropic, OpenAI, modelo próprio etc.) for conectado. Todas as
 * páginas do site chamam apenas as funções exportadas aqui — nunca uma API
 * de IA diretamente — para que o provedor possa ser substituído sem alterar
 * a interface.
 *
 * Hoje as respostas são simuladas (mock) porque nenhuma chave de API foi
 * configurada nesta sessão.
 */

export interface AiMessage {
  role: "user" | "assistant";
  content: string;
}

function pickTemplate(templates: string[], seed: string) {
  const idx =
    Math.abs(
      seed.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0)
    ) % templates.length;
  return templates[idx];
}

function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Simula uma resposta de chat da IA, em português brasileiro, com um
 * pequeno atraso para imitar processamento real.
 */
export async function mockChatResponse(
  history: AiMessage[]
): Promise<string> {
  const lastUser = [...history].reverse().find((m) => m.role === "user");
  const text = lastUser?.content?.toLowerCase().trim() ?? "";

  await wait(600 + Math.random() * 500);

  if (!text) {
    return "Pode me contar um pouco mais sobre o que você precisa? Posso explicar textos, resumir documentos, esclarecer palavras difíceis ou ajudar com Libras e acessibilidade.";
  }

  if (text.includes("resum")) {
    return "Aqui está um resumo simulado: o texto apresenta uma ideia principal, alguns pontos de apoio e uma conclusão. Quando a IA estiver conectada a um provedor real, este resumo será gerado a partir do conteúdo que você enviar, mantendo linguagem clara e direta.";
  }
  if (text.includes("explic")) {
    return "Posso explicar de forma simples: pense nisso como dividir a informação em partes menores e mais fáceis de entender, sem perder o significado original. Envie o trecho específico que você quer que eu explique.";
  }
  if (text.includes("libras")) {
    return "Sobre Libras: sou um assistente em desenvolvimento e ainda não tenho tradução automática confiável. Recomendo consultar o Dicionário de Libras da plataforma ou um intérprete humano para contextos importantes.";
  }
  if (text.includes("palavra") || text.includes("significa")) {
    return "Essa palavra, de forma simples, costuma se referir ao conceito central da frase em que aparece. Se você enviar a frase completa, consigo dar uma explicação mais precisa.";
  }
  if (text.includes("document") || text.includes("pdf") || text.includes("contrato")) {
    return "Recebi a referência ao documento. Em uma versão conectada a um provedor de IA real, eu leria o conteúdo enviado e traria um resumo dos pontos principais, prazos e responsabilidades, em linguagem simples.";
  }

  const generic = [
    "Entendi. Posso resumir, explicar em linguagem simples ou destacar os pontos principais desse conteúdo — o que você prefere?",
    "Essa é uma boa pergunta. No momento estou funcionando em modo de demonstração, mas já estou organizado para responder com base em textos, documentos e imagens que você enviar.",
    "Posso ajudar com isso. Se quiser, envie um arquivo, uma imagem ou mais detalhes para eu dar uma resposta mais completa.",
    "Certo. Lembre-se: para Libras, ainda estou em fase experimental — o ideal é sempre confirmar informações importantes com um intérprete humano.",
  ];

  return pickTemplate(generic, text);
}

export async function mockSummarize(text: string): Promise<string> {
  await wait(700);
  const words = text.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) {
    return "Cole ou digite um texto para que eu possa gerar um resumo.";
  }
  const preview = words.slice(0, 28).join(" ");
  return `Resumo (simulado): ${preview}${words.length > 28 ? "…" : ""} — em uma versão conectada a um provedor de IA real, este resumo será gerado automaticamente a partir do conteúdo completo, priorizando os pontos mais importantes.`;
}

export async function mockExplainSimple(text: string): Promise<string> {
  await wait(700);
  if (!text.trim()) {
    return "Cole ou digite um texto para eu explicar em linguagem simples.";
  }
  return "Explicação em linguagem simples (simulada): a ideia principal do texto foi reorganizada em frases curtas e diretas, evitando termos técnicos sem necessidade. Quando a IA estiver conectada, essa explicação será gerada a partir do conteúdo real enviado.";
}

export async function mockGenerateQuestions(text: string): Promise<string[]> {
  await wait(700);
  if (!text.trim()) return [];
  return [
    "Qual é a ideia principal do texto?",
    "Quais são os pontos de apoio apresentados?",
    "Como esse conteúdo pode ser aplicado na prática?",
    "Existe algum termo que precisa de mais explicação?",
  ];
}

export async function mockGenerateFlashcards(
  text: string
): Promise<{ front: string; back: string }[]> {
  await wait(800);
  if (!text.trim()) return [];
  return [
    {
      front: "Qual é o tema central do conteúdo estudado?",
      back: "Resposta simulada com base no texto enviado.",
    },
    {
      front: "Cite um ponto importante mencionado no texto.",
      back: "Resposta simulada — será gerada a partir do conteúdo real quando a IA estiver conectada.",
    },
    {
      front: "Como esse conteúdo se relaciona com o que você já sabe?",
      back: "Reflita e complete com suas próprias palavras.",
    },
  ];
}

export async function mockOcrDescribeActions(): Promise<string> {
  await wait(400);
  return "Texto reconhecido com sucesso. Você pode copiar, ouvir, resumir ou pedir uma explicação para a IA.";
}
