import generatedSigns from "@/data/libras-dictionary.json";

export type SignStatus = "revisado" | "em_revisao";

export interface SignEntry {
  id: string;
  word: string;
  category: string;
  description: string;
  example: string;
  region?: string;
  /** URL do vídeo do sinal. Ausente enquanto o sinal ainda não foi gravado. */
  videoUrl?: string;
  /** Imagem estática exibida antes do vídeo carregar. */
  posterUrl?: string;
  /** "revisado" = validado por pessoa surda/linguista de Libras. */
  status: SignStatus;
  updatedAt?: string;
}

/**
 * Fonte de dados do dicionário de Libras.
 *
 * Este arquivo é gerado automaticamente a partir de
 * content/sinais-libras.csv pelo script scripts/gerar-dicionario-libras.mjs
 * (rode "npm run libras:gerar" após editar o CSV, ou apenas "npm run dev" /
 * "npm run build", que já rodam o script antes). Isso permite que a equipe
 * de conteúdo adicione ou corrija sinais numa planilha, sem tocar em
 * código — escala para centenas ou milhares de sinais sem precisar editar
 * este arquivo TypeScript manualmente.
 */
export const SIGN_LIBRARY: SignEntry[] = generatedSigns as SignEntry[];

// A ordem fixa aqui garante os filtros sempre na mesma ordem na interface,
// mesmo que novas categorias apareçam no CSV antes de serem adicionadas aqui.
const KNOWN_CATEGORY_ORDER = [
  "Tecnologia",
  "Educação",
  "Saúde",
  "Trabalho",
  "Comunicação",
  "Casa",
  "Alimentação",
  "Transporte",
  "Serviços públicos",
];

export const SIGN_CATEGORIES: string[] = Array.from(
  new Set(SIGN_LIBRARY.map((s) => s.category))
).sort((a, b) => {
  const ia = KNOWN_CATEGORY_ORDER.indexOf(a);
  const ib = KNOWN_CATEGORY_ORDER.indexOf(b);
  if (ia === -1 && ib === -1) return a.localeCompare(b, "pt-BR");
  if (ia === -1) return 1;
  if (ib === -1) return -1;
  return ia - ib;
});

export interface PhraseCategory {
  category: string;
  phrases: string[];
}

export const USEFUL_PHRASES: PhraseCategory[] = [
  {
    category: "Escola",
    phrases: [
      "Não entendi essa parte, pode explicar de novo?",
      "Posso usar o intérprete de Libras nesta aula?",
      "Qual é o prazo de entrega do trabalho?",
    ],
  },
  {
    category: "Trabalho",
    phrases: [
      "Podemos usar legendas nessa reunião?",
      "Preciso de um intérprete de Libras para esta apresentação.",
      "Pode repetir e falar de frente para mim, por favor?",
    ],
  },
  {
    category: "Saúde",
    phrases: [
      "Sou surdo(a) e preciso de comunicação por escrito ou Libras.",
      "Pode explicar o diagnóstico em linguagem simples?",
      "Existe intérprete de Libras disponível neste atendimento?",
    ],
  },
  {
    category: "Atendimento",
    phrases: [
      "Podemos nos comunicar por texto, por favor?",
      "Sou surdo(a), pode escrever a informação?",
      "Obrigado(a) pela paciência.",
    ],
  },
  {
    category: "Tecnologia",
    phrases: [
      "O aplicativo está travando, pode me ajudar?",
      "Como eu ativo a legenda automática?",
      "Onde encontro o histórico de transcrições?",
    ],
  },
  {
    category: "Viagem",
    phrases: [
      "Qual o horário de saída do voo/ônibus?",
      "Pode escrever o endereço, por favor?",
      "Existe atendimento acessível para pessoas surdas aqui?",
    ],
  },
  {
    category: "Serviços públicos",
    phrases: [
      "Preciso de intérprete de Libras para este atendimento.",
      "Pode me explicar esse formulário em linguagem simples?",
      "Qual é o próximo passo do processo?",
    ],
  },
];
