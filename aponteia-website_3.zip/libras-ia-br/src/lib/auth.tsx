"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

export interface MockUser {
  name: string;
  email: string;
  createdAt: string;
  photo?: string;
  preferences?: {
    idioma: string;
  };
}

interface AuthContextValue {
  user: MockUser | null;
  loading: boolean;
  login: (email: string, _password: string) => Promise<MockUser>;
  register: (name: string, email: string, _password: string) => Promise<MockUser>;
  loginWithProvider: (provider: "google" | "apple") => Promise<MockUser>;
  logout: () => void;
  updateProfile: (patch: Partial<MockUser>) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);
const STORAGE_KEY = "libras-ia:usuario";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<MockUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Lê a sessão salva apenas no cliente, após a primeira renderização
    // (armazenamento local não existe no servidor).
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      // eslint-disable-next-line react-hooks/set-state-in-effect
      if (raw) setUser(JSON.parse(raw));
    } catch {
      // ignore
    }
    setLoading(false);
  }, []);

  const persist = useCallback((u: MockUser | null) => {
    setUser(u);
    try {
      if (u) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
      else window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }, []);

  const login = useCallback(
    async (email: string, _password: string) => {
      await new Promise((r) => setTimeout(r, 500));
      const u: MockUser = {
        name: email.split("@")[0].replace(/[._]/g, " "),
        email,
        createdAt: new Date().toISOString(),
      };
      persist(u);
      return u;
    },
    [persist]
  );

  const register = useCallback(
    async (name: string, email: string, _password: string) => {
      await new Promise((r) => setTimeout(r, 600));
      const u: MockUser = { name, email, createdAt: new Date().toISOString() };
      persist(u);
      return u;
    },
    [persist]
  );

  const loginWithProvider = useCallback(
    async (provider: "google" | "apple") => {
      await new Promise((r) => setTimeout(r, 500));
      const u: MockUser = {
        name: provider === "google" ? "Usuário Google" : "Usuário Apple",
        email: `usuario@${provider}.com`,
        createdAt: new Date().toISOString(),
      };
      persist(u);
      return u;
    },
    [persist]
  );

  const logout = useCallback(() => persist(null), [persist]);

  const updateProfile = useCallback(
    (patch: Partial<MockUser>) => {
      setUser((prev) => {
        if (!prev) return prev;
        const next = { ...prev, ...patch };
        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
        } catch {
          // ignore
        }
        return next;
      });
    },
    []
  );

  const value = useMemo(
    () => ({ user, loading, login, register, loginWithProvider, logout, updateProfile }),
    [user, loading, login, register, loginWithProvider, logout, updateProfile]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de AuthProvider");
  return ctx;
}
