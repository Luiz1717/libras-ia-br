export interface SubtitleCue {
  id: string;
  start: number;
  end: number;
  text: string;
}

export type SubtitlePosition = "topo" | "centro" | "rodape";
export type SubtitleAlign = "esquerda" | "centro" | "direita";

export interface SubtitleStyle {
  font: string;
  size: number;
  position: SubtitlePosition;
  background: boolean;
  align: SubtitleAlign;
}

export const DEFAULT_SUBTITLE_STYLE: SubtitleStyle = {
  font: "Sans-serif",
  size: 22,
  position: "rodape",
  background: true,
  align: "centro",
};

const SAMPLE_LINES = [
  "Olá, seja bem-vindo a este vídeo.",
  "Hoje vamos falar sobre acessibilidade e tecnologia.",
  "A inteligência artificial pode ajudar a reduzir barreiras.",
  "Legendas automáticas facilitam o acesso à informação.",
  "É importante revisar o conteúdo gerado automaticamente.",
  "Cada pessoa se comunica de um jeito diferente.",
  "A tecnologia deve se adaptar às pessoas, não o contrário.",
  "Obrigado por assistir até aqui.",
];

export function generateMockCues(durationSeconds: number): SubtitleCue[] {
  const total = Math.max(durationSeconds, 8);
  const count = Math.min(SAMPLE_LINES.length, Math.max(4, Math.floor(total / 4)));
  const segment = total / count;
  return Array.from({ length: count }, (_, i) => {
    const start = i * segment + 0.3;
    const end = start + Math.min(segment - 0.6, 4.5);
    return {
      id: `cue-${i}`,
      start: Number(start.toFixed(2)),
      end: Number(Math.max(end, start + 1).toFixed(2)),
      text: SAMPLE_LINES[i % SAMPLE_LINES.length],
    };
  });
}

function pad(n: number, size = 2) {
  return n.toString().padStart(size, "0");
}

function formatTime(seconds: number, msSeparator: "," | ".") {
  const s = Math.max(0, seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  const ms = Math.round((s - Math.floor(s)) * 1000);
  return `${pad(h)}:${pad(m)}:${pad(sec)}${msSeparator}${pad(ms, 3)}`;
}

export function generateSrt(cues: SubtitleCue[]): string {
  return cues
    .map(
      (cue, i) =>
        `${i + 1}\n${formatTime(cue.start, ",")} --> ${formatTime(cue.end, ",")}\n${cue.text}\n`
    )
    .join("\n");
}

export function generateVtt(cues: SubtitleCue[]): string {
  const body = cues
    .map((cue) => `${formatTime(cue.start, ".")} --> ${formatTime(cue.end, ".")}\n${cue.text}\n`)
    .join("\n");
  return `WEBVTT\n\n${body}`;
}

export function downloadTextFile(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function formatClock(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${pad(m)}:${pad(s)}`;
}
