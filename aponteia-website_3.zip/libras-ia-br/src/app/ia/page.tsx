import type { Metadata } from "next";
import { IaClient } from "./IaClient";

export const metadata: Metadata = {
  title: "Assistente de IA",
  description:
    "Converse com o assistente de IA do AponteIA: explique textos, resuma documentos e tire dúvidas em português brasileiro.",
};

export default function Page() {
  return <IaClient />;
}
