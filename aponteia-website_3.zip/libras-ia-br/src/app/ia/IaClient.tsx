"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import {
  Send,
  Paperclip,
  Image as ImageIcon,
  Mic,
  MicOff,
  Bot,
  User,
  Plus,
  MessageSquare,
  X,
  FileText,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { mockChatResponse, type AiMessage } from "@/lib/ai";
import { addHistoryItem } from "@/lib/history";
import { useSpeechRecognition } from "@/lib/useSpeechRecognition";

interface UploadedFile {
  id: string;
  name: string;
  status: "enviando" | "processando" | "concluido";
}

const SUGGESTIONS = [
  "Explique esse texto em linguagem simples.",
  "Resuma esse artigo para mim.",
  "O que significa essa palavra?",
  "Transforme esse texto em linguagem simples.",
];

const PAST_CONVERSATIONS = [
  "Explicação sobre contrato de aluguel",
  "Resumo do artigo de acessibilidade",
  "Dúvidas sobre Libras formal",
];

export function IaClient() {
  const [messages, setMessages] = useState<AiMessage[]>([
    {
      role: "assistant",
      content:
        "Olá! Sou o assistente de IA do AponteIA. Posso explicar textos, resumir documentos e responder dúvidas em português. Como posso ajudar hoje?",
    },
  ]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [savedHistory, setSavedHistory] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const {
    supported: micSupported,
    listening,
    finalText,
    start,
    stop,
    reset: resetSpeech,
  } = useSpeechRecognition();

  useEffect(() => {
    // Sincroniza o campo de texto com o resultado do reconhecimento de voz
    // (uma API externa do navegador).
    if (finalText) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setInput((prev) => (prev ? `${prev} ${finalText}` : finalText).trim());
      resetSpeech();
    }
  }, [finalText, resetSpeech]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, sending]);

  function handleFiles(list: FileList | null, kind: "arquivo" | "imagem") {
    if (!list || list.length === 0) return;
    const items: UploadedFile[] = Array.from(list).map((f) => ({
      id: `${Date.now()}-${f.name}`,
      name: f.name,
      status: "enviando",
    }));
    setFiles((prev) => [...prev, ...items]);

    items.forEach((item, idx) => {
      window.setTimeout(() => {
        setFiles((prev) =>
          prev.map((f) => (f.id === item.id ? { ...f, status: "processando" } : f))
        );
      }, 500 + idx * 200);
      window.setTimeout(() => {
        setFiles((prev) =>
          prev.map((f) => (f.id === item.id ? { ...f, status: "concluido" } : f))
        );
      }, 1400 + idx * 200);
    });

    setMessages((prev) => [
      ...prev,
      {
        role: "assistant",
        content:
          kind === "imagem"
            ? "Recebi sua imagem. Em uma versão conectada a um provedor de IA real, eu analisaria o conteúdo visual. Por enquanto, conte-me o que você gostaria de saber sobre ela."
            : "Recebi seu arquivo. Em uma versão conectada a um provedor de IA real, eu leria o conteúdo e poderia resumir, explicar ou responder perguntas sobre ele.",
      },
    ]);
  }

  async function handleSend(e: FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || sending) return;

    const nextMessages: AiMessage[] = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setSending(true);

    if (!savedHistory) {
      addHistoryItem({ type: "conversa", title: text.slice(0, 60), preview: text });
      setSavedHistory(true);
    }

    const reply = await mockChatResponse(nextMessages);
    setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
    setSending(false);
  }

  function toggleMic() {
    if (listening) stop();
    else start();
  }

  return (
    <div className="flex h-[calc(100vh-4rem)] sm:h-[calc(100vh-70px)]">
      <aside
        className={`${
          sidebarOpen ? "flex" : "hidden"
        } lg:flex w-72 shrink-0 flex-col border-r border-[var(--color-border)] bg-[var(--color-bg-subtle)] absolute lg:static inset-y-0 left-0 z-30 lg:z-0`}
      >
        <div className="flex items-center justify-between p-4">
          <button className="flex flex-1 items-center gap-2 rounded-xl bg-[var(--color-primary)] px-4 py-2.5 text-sm font-semibold text-[var(--color-primary-contrast)]">
            <Plus className="h-4 w-4" aria-hidden="true" />
            Nova conversa
          </button>
          <button
            className="ml-2 rounded-lg p-2 lg:hidden"
            aria-label="Fechar menu lateral"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <nav aria-label="Conversas anteriores" className="flex-1 overflow-y-auto px-3 pb-4 scrollbar-thin">
          <p className="px-2 py-1 text-xs font-semibold uppercase text-[var(--color-text-muted)]">
            Conversas recentes
          </p>
          {PAST_CONVERSATIONS.map((c) => (
            <button
              key={c}
              className="mt-1 flex w-full items-center gap-2 truncate rounded-lg px-3 py-2.5 text-left text-sm text-[var(--color-text-muted)] hover:bg-[var(--color-bg)] hover:text-[var(--color-text)]"
            >
              <MessageSquare className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span className="truncate">{c}</span>
            </button>
          ))}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-center gap-2 border-b border-[var(--color-border)] p-3 lg:hidden">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-sm font-medium"
          >
            Conversas
          </button>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto scrollbar-thin">
          <Container className="flex flex-col gap-5 py-6">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex items-start gap-3 ${m.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <span
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
                    m.role === "user"
                      ? "bg-[var(--color-accent)] text-[var(--color-accent-contrast)]"
                      : "bg-[var(--color-primary)] text-[var(--color-primary-contrast)]"
                  }`}
                  aria-hidden="true"
                >
                  {m.role === "user" ? <User className="h-4.5 w-4.5" /> : <Bot className="h-4.5 w-4.5" />}
                </span>
                <div
                  className={`max-w-[75%] rounded-2xl px-4 py-3 text-[15px] leading-relaxed ${
                    m.role === "user"
                      ? "bg-[var(--color-primary)] text-[var(--color-primary-contrast)]"
                      : "border border-[var(--color-border)] bg-[var(--color-surface)]"
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {sending && (
              <div className="flex items-start gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--color-primary)] text-[var(--color-primary-contrast)]" aria-hidden="true">
                  <Bot className="h-4.5 w-4.5" />
                </span>
                <div
                  role="status"
                  aria-live="polite"
                  className="flex items-center gap-1.5 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] px-4 py-3"
                >
                  <span className="sr-only">A IA está digitando</span>
                  <span className="h-2 w-2 animate-pulse-soft rounded-full bg-[var(--color-text-muted)]" />
                  <span className="h-2 w-2 animate-pulse-soft rounded-full bg-[var(--color-text-muted)] [animation-delay:0.15s]" />
                  <span className="h-2 w-2 animate-pulse-soft rounded-full bg-[var(--color-text-muted)] [animation-delay:0.3s]" />
                </div>
              </div>
            )}
            {messages.length === 1 && (
              <div className="grid gap-2 sm:grid-cols-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => setInput(s)}
                    className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)] p-3 text-left text-sm text-[var(--color-text-muted)] hover:border-[var(--color-primary)] hover:text-[var(--color-text)]"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
          </Container>
        </div>

        <div className="border-t border-[var(--color-border)] bg-[var(--color-bg)] p-3 sm:p-4">
          <Container>
            {files.length > 0 && (
              <div className="mb-3 flex flex-wrap gap-2">
                {files.map((f) => (
                  <span
                    key={f.id}
                    className="flex items-center gap-2 rounded-full border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-3 py-1.5 text-xs font-medium"
                  >
                    <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                    <span className="max-w-[140px] truncate">{f.name}</span>
                    <span className="text-[var(--color-text-muted)]">
                      {f.status === "enviando" && "Enviando…"}
                      {f.status === "processando" && "Processando…"}
                      {f.status === "concluido" && "Concluído"}
                    </span>
                  </span>
                ))}
              </div>
            )}
            {listening && (
              <p role="status" className="mb-2 flex items-center gap-2 text-sm font-medium text-[var(--color-primary)]">
                <span className="flex gap-0.5" aria-hidden="true">
                  <span className="h-3 w-1 animate-wave rounded-full bg-[var(--color-primary)]" />
                  <span className="h-3 w-1 animate-wave rounded-full bg-[var(--color-primary)] [animation-delay:0.15s]" />
                  <span className="h-3 w-1 animate-wave rounded-full bg-[var(--color-primary)] [animation-delay:0.3s]" />
                </span>
                Ouvindo…
              </p>
            )}
            <form onSubmit={handleSend} className="flex items-end gap-2">
              <div className="flex gap-1">
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  multiple
                  accept=".pdf,.docx,.txt,audio/*,video/*"
                  onChange={(e) => handleFiles(e.target.files, "arquivo")}
                />
                <input
                  ref={imageInputRef}
                  type="file"
                  className="hidden"
                  multiple
                  accept="image/*"
                  onChange={(e) => handleFiles(e.target.files, "imagem")}
                />
                <button
                  type="button"
                  aria-label="Enviar arquivo"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-[var(--color-border)] hover:bg-[var(--color-bg-subtle)]"
                >
                  <Paperclip className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  aria-label="Enviar imagem"
                  onClick={() => imageInputRef.current?.click()}
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-[var(--color-border)] hover:bg-[var(--color-bg-subtle)]"
                >
                  <ImageIcon className="h-5 w-5" />
                </button>
                {micSupported && (
                  <button
                    type="button"
                    aria-label={listening ? "Parar ditado por voz" : "Ditar por voz"}
                    aria-pressed={listening}
                    onClick={toggleMic}
                    className={`flex h-11 w-11 items-center justify-center rounded-full border ${
                      listening
                        ? "border-red-500 bg-red-500/10 text-red-600"
                        : "border-[var(--color-border)] hover:bg-[var(--color-bg-subtle)]"
                    }`}
                  >
                    {listening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                  </button>
                )}
              </div>
              <label htmlFor="chat-input" className="sr-only">
                Digite sua mensagem
              </label>
              <textarea
                id="chat-input"
                rows={1}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend(e);
                  }
                }}
                placeholder="Digite sua mensagem…"
                className="max-h-32 min-h-[44px] flex-1 resize-none rounded-2xl border-2 border-[var(--color-border)] bg-[var(--color-surface)] px-4 py-2.5 outline-none focus:border-[var(--color-primary)]"
              />
              <button
                type="submit"
                disabled={!input.trim() || sending}
                aria-label="Enviar mensagem"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[var(--color-primary)] text-[var(--color-primary-contrast)] disabled:opacity-40"
              >
                <Send className="h-5 w-5" />
              </button>
            </form>
            <p className="mt-2 text-center text-xs text-[var(--color-text-muted)]">
              As respostas são simuladas nesta demonstração e podem conter imprecisões.
            </p>
          </Container>
        </div>
      </div>
    </div>
  );
}
