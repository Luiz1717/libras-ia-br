import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/dashboard", "/perfil", "/historico", "/admin"],
      },
    ],
    sitemap: "https://aponteia.exemplo.com.br/sitemap.xml",
  };
}
