import type { Metadata } from "next";
import Link from "next/link";
import {
  Mic,
  Volume2,
  Captions,
  ScanText,
  Hand,
  Bot,
  ArrowRight,
  Users,
  Presentation,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, Badge } from "@/components/ui/Card";

export const metadata: Metadata = {
  title: "Ferramentas",
  description: "Todas as ferramentas de acessibilidade do AponteIA em um só lugar.",
};

const TOOLS = [
  {
    href: "/voz-para-texto",
    icon: Mic,
    title: "Fala → Texto",
    description: "Transcrição em tempo real, direto do navegador.",
  },
  {
    href: "/texto-para-voz",
    icon: Volume2,
    title: "Texto → Voz",
    description: "Transforme qualquer texto em áudio falado.",
  },
  {
    href: "/legendas",
    icon: Captions,
    title: "Vídeo → Legenda",
    description: "Gere, edite e exporte legendas em SRT e VTT.",
  },
  {
    href: "/ocr",
    icon: ScanText,
    title: "Imagem → Texto (OCR)",
    description: "Reconheça texto em fotos e imagens.",
  },
  {
    href: "/libras",
    icon: Hand,
    title: "Libras",
    description: "Dicionário, frases úteis e reconhecimento experimental.",
    badge: "Experimental",
  },
  {
    href: "/ia",
    icon: Bot,
    title: "Assistente IA",
    description: "Converse, resuma e explique conteúdos com IA.",
  },
  {
    href: "/educacao",
    icon: Presentation,
    title: "Educação",
    description: "Ferramentas de estudo para estudantes e professores.",
  },
  {
    href: "/contribuir",
    icon: Users,
    title: "Faça parte do projeto",
    description: "Envie sugestões, relate erros e participe de testes.",
  },
];

export default function FerramentasPage() {
  return (
    <>
      <PageHeader
        eyebrow="Tudo em um lugar"
        title="Ferramentas"
        description="Todas as ferramentas de acessibilidade do AponteIA, organizadas para você encontrar rápido o que precisa."
      />
      <Container className="py-10 sm:py-14">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {TOOLS.map((tool) => (
            <Link key={tool.href} href={tool.href} className="group">
              <Card className="flex h-full flex-col transition-colors group-hover:border-[var(--color-primary)]">
                <div className="flex items-start justify-between">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--color-primary)]/10 text-[var(--color-primary)]">
                    <tool.icon className="h-6 w-6" aria-hidden="true" />
                  </span>
                  {tool.badge && <Badge tone="warning">{tool.badge}</Badge>}
                </div>
                <h3 className="mt-4 text-lg font-semibold">{tool.title}</h3>
                <p className="mt-1.5 flex-1 text-sm text-[var(--color-text-muted)]">
                  {tool.description}
                </p>
                <span className="mt-4 flex items-center gap-1.5 text-sm font-semibold text-[var(--color-primary)]">
                  Abrir <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </span>
              </Card>
            </Link>
          ))}
        </div>
      </Container>
    </>
  );
}
