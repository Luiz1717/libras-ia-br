import type { Metadata } from "next";
import Link from "next/link";
import {
  Mic,
  Volume2,
  Captions,
  ScanText,
  Hand,
  Bot,
  ArrowRight,
  GraduationCap,
  ShieldCheck,
  Users,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/Button";
import { Card, Badge } from "@/components/ui/Card";
import { HeroVisual } from "@/components/HeroVisual";

export const metadata: Metadata = {
  title: "Início",
  description:
    "Plataforma brasileira de tecnologia assistiva com Inteligência Artificial: Libras, legendas automáticas, fala para texto, texto para voz e OCR — pensada com e para a comunidade surda.",
};

const TOOLS = [
  {
    href: "/voz-para-texto",
    icon: Mic,
    title: "Fala → Texto",
    description: "Transforme fala em texto em tempo real, direto no navegador.",
    cta: "Experimentar",
  },
  {
    href: "/texto-para-voz",
    icon: Volume2,
    title: "Texto → Voz",
    description: "Digite um texto e transforme em áudio com voz em português.",
    cta: "Experimentar",
  },
  {
    href: "/legendas",
    icon: Captions,
    title: "Vídeo → Legenda",
    description: "Envie um vídeo e gere legendas automaticamente, prontas para editar.",
    cta: "Gerar legenda",
  },
  {
    href: "/ocr",
    icon: ScanText,
    title: "Imagem → Texto",
    description: "Envie ou fotografe uma imagem e reconheça o conteúdo textual.",
    cta: "Ler imagem",
  },
  {
    href: "/libras",
    icon: Hand,
    title: "Libras → Texto",
    description: "Abra a câmera e use o reconhecimento experimental de Libras.",
    cta: "Experimentar Libras",
    experimental: true,
  },
  {
    href: "/ia",
    icon: Bot,
    title: "Assistente IA",
    description: "Converse com uma IA especializada em acessibilidade e Libras.",
    cta: "Conversar com IA",
  },
];

const AUDIENCES = [
  "Pessoas surdas",
  "Estudantes",
  "Professores e intérpretes",
  "Famílias",
  "Empresas e escolas",
];

export default function Home() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-[var(--color-border)]">
        <Container className="grid items-center gap-12 py-16 sm:py-20 lg:grid-cols-2 lg:py-28">
          <div>
            <Badge tone="primary" className="mb-5">
              Feito com a comunidade surda brasileira
            </Badge>
            <h1 className="text-4xl font-bold leading-tight tracking-tight text-[var(--color-text)] sm:text-5xl">
              Inteligência Artificial para acessibilidade e comunicação.
            </h1>
            <p className="mt-6 max-w-xl text-lg text-[var(--color-text-muted)]">
              Tecnologia criada para aproximar Libras, português, texto, voz e informação,
              ajudando a reduzir barreiras de comunicação para a comunidade surda brasileira.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <ButtonLink href="/cadastro" size="lg">
                Começar agora
                <ArrowRight className="h-5 w-5" aria-hidden="true" />
              </ButtonLink>
              <ButtonLink href="/ferramentas" size="lg" variant="outline">
                Conhecer as ferramentas
              </ButtonLink>
            </div>
            <div className="mt-8 flex flex-wrap gap-2">
              {AUDIENCES.map((a) => (
                <span
                  key={a}
                  className="rounded-full border border-[var(--color-border)] px-3 py-1 text-xs font-medium text-[var(--color-text-muted)]"
                >
                  {a}
                </span>
              ))}
            </div>
          </div>
          <HeroVisual />
        </Container>
      </section>

      <section className="py-16 sm:py-20" aria-labelledby="ferramentas-heading">
        <Container>
          <div className="mx-auto max-w-2xl text-center">
            <h2 id="ferramentas-heading" className="text-3xl font-bold tracking-tight sm:text-4xl">
              O que você pode fazer?
            </h2>
            <p className="mt-3 text-lg text-[var(--color-text-muted)]">
              Ferramentas de acessibilidade prontas para usar, direto do navegador.
            </p>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {TOOLS.map((tool) => (
              <Card key={tool.href} className="flex flex-col">
                <span
                  className="flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--color-primary)]/10 text-[var(--color-primary)]"
                  aria-hidden="true"
                >
                  <tool.icon className="h-6 w-6" />
                </span>
                <h3 className="mt-4 text-xl font-semibold">{tool.title}</h3>
                <p className="mt-2 flex-1 text-[var(--color-text-muted)]">
                  {tool.description}
                </p>
                {tool.experimental && (
                  <p className="mt-3 text-xs text-amber-700 dark:text-amber-400">
                    O reconhecimento de Libras ainda está em desenvolvimento e pode
                    apresentar erros.
                  </p>
                )}
                <Link
                  href={tool.href}
                  className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-[var(--color-primary)] hover:underline"
                >
                  {tool.cta}
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      <section className="border-y border-[var(--color-border)] bg-[var(--color-bg-subtle)] py-16 sm:py-20">
        <Container className="grid gap-10 lg:grid-cols-3">
          <div className="lg:col-span-1">
            <p className="text-2xl font-semibold leading-snug text-[var(--color-text)]">
              &ldquo;Tecnologia que aproxima pessoas. Inteligência Artificial que amplia a
              acessibilidade.&rdquo;
            </p>
            <p className="mt-4 text-[var(--color-text-muted)]">
              Uma IA para surdos, criada com a comunidade surda e para ampliar autonomia,
              comunicação, informação, educação e oportunidades.
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-3 lg:col-span-2">
            <div className="flex flex-col items-start gap-3 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
              <Users className="h-6 w-6 text-[var(--color-primary)]" aria-hidden="true" />
              <h3 className="font-semibold">Feito em conjunto</h3>
              <p className="text-sm text-[var(--color-text-muted)]">
                A comunidade surda participa dos testes e da validação de cada
                funcionalidade.
              </p>
            </div>
            <div className="flex flex-col items-start gap-3 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
              <ShieldCheck className="h-6 w-6 text-[var(--color-primary)]" aria-hidden="true" />
              <h3 className="font-semibold">Privacidade em primeiro lugar</h3>
              <p className="text-sm text-[var(--color-text-muted)]">
                Você controla seus dados e arquivos, com práticas alinhadas à LGPD.
              </p>
            </div>
            <div className="flex flex-col items-start gap-3 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5">
              <GraduationCap className="h-6 w-6 text-[var(--color-primary)]" aria-hidden="true" />
              <h3 className="font-semibold">Educação acessível</h3>
              <p className="text-sm text-[var(--color-text-muted)]">
                Recursos pensados para estudantes surdos, professores e intérpretes.
              </p>
            </div>
          </div>
        </Container>
      </section>

      <section className="py-16 sm:py-20">
        <Container className="flex flex-col items-center gap-6 rounded-3xl border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-10 text-center sm:p-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Pronto para começar?
          </h2>
          <p className="max-w-xl text-lg text-[var(--color-text-muted)]">
            Crie sua conta gratuita e tenha acesso ao histórico das suas transcrições,
            legendas e conversas com a IA.
          </p>
          <ButtonLink href="/cadastro" size="lg">
            Criar conta gratuita
          </ButtonLink>
        </Container>
      </section>
    </>
  );
}
