import type { Metadata } from "next";
import { HistoricoClient } from "./HistoricoClient";

export const metadata: Metadata = {
  title: "Histórico",
  description: "Consulte, pesquise e gerencie suas transcrições, legendas, resumos e conversas.",
};

export default function Page() {
  return <HistoricoClient />;
}
