"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Search,
  Pencil,
  Trash2,
  Share2,
  Check,
  X,
  FolderOpen,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, Badge } from "@/components/ui/Card";
import { RequireAuthNotice } from "@/components/RequireAuthNotice";
import { useAuth } from "@/lib/auth";
import {
  getHistory,
  removeHistoryItem,
  renameHistoryItem,
  historyTypeLabel,
  type HistoryItem,
  type HistoryType,
} from "@/lib/history";

const FILTERS: { value: HistoryType | "todos"; label: string }[] = [
  { value: "todos", label: "Todos" },
  { value: "transcricao", label: "Transcrições" },
  { value: "legenda", label: "Legendas" },
  { value: "conversa", label: "Conversas" },
  { value: "documento", label: "Documentos" },
  { value: "resumo", label: "Resumos" },
  { value: "ocr", label: "Leituras de imagem" },
];

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function HistoricoClient() {
  const { user, loading } = useAuth();
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<HistoryType | "todos">("todos");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [shareMessage, setShareMessage] = useState<string | null>(null);

  useEffect(() => {
    // Lê o histórico salvo no armazenamento local, disponível só no cliente.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (user) setItems(getHistory());
  }, [user]);

  const filtered = useMemo(() => {
    return items.filter((item) => {
      const matchesFilter = filter === "todos" || item.type === filter;
      const matchesQuery =
        query.trim() === "" ||
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.preview.toLowerCase().includes(query.toLowerCase());
      return matchesFilter && matchesQuery;
    });
  }, [items, filter, query]);

  function handleDelete(id: string) {
    removeHistoryItem(id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  function startRename(item: HistoryItem) {
    setEditingId(item.id);
    setEditValue(item.title);
  }

  function confirmRename(id: string) {
    if (editValue.trim()) {
      renameHistoryItem(id, editValue.trim());
      setItems((prev) =>
        prev.map((i) => (i.id === id ? { ...i, title: editValue.trim() } : i))
      );
    }
    setEditingId(null);
  }

  function handleShare(item: HistoryItem) {
    setShareMessage(`Link de compartilhamento copiado para "${item.title}" (simulado).`);
    window.setTimeout(() => setShareMessage(null), 3000);
  }

  if (loading) return null;
  if (!user) return <RequireAuthNotice title="Histórico" />;

  return (
    <>
      <PageHeader
        eyebrow="Sua conta"
        title="Histórico"
        description="Transcrições, legendas, resumos, traduções e conversas ficam salvos aqui."
      />
      <Container className="py-10 sm:py-14">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[var(--color-text-muted)]"
              aria-hidden="true"
            />
            <label htmlFor="busca-historico" className="sr-only">
              Pesquisar no histórico
            </label>
            <input
              id="busca-historico"
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Pesquisar no histórico…"
              className="w-full rounded-full border-2 border-[var(--color-border)] bg-[var(--color-surface)] py-2.5 pl-11 pr-4 outline-none focus:border-[var(--color-primary)]"
            />
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Filtrar por tipo">
          {FILTERS.map((f) => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              aria-pressed={filter === f.value}
              className={`rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors ${
                filter === f.value
                  ? "border-[var(--color-primary)] bg-[var(--color-primary)]/10 text-[var(--color-primary)]"
                  : "border-[var(--color-border)] text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {shareMessage && (
          <p role="status" className="mt-4 rounded-xl bg-emerald-500/10 px-4 py-2.5 text-sm font-medium text-emerald-700 dark:text-emerald-400">
            {shareMessage}
          </p>
        )}

        <div className="mt-6 flex flex-col gap-3">
          {filtered.length === 0 && (
            <Card className="flex flex-col items-center gap-2 py-14 text-center text-[var(--color-text-muted)]">
              <FolderOpen className="h-8 w-8" aria-hidden="true" />
              Nenhum item encontrado.
            </Card>
          )}
          {filtered.map((item) => (
            <Card key={item.id} className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1">
                {editingId === item.id ? (
                  <div className="flex items-center gap-2">
                    <label htmlFor={`rename-${item.id}`} className="sr-only">
                      Novo nome
                    </label>
                    <input
                      id={`rename-${item.id}`}
                      autoFocus
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      className="w-full rounded-lg border-2 border-[var(--color-primary)] bg-[var(--color-bg)] px-3 py-1.5 outline-none"
                    />
                    <button
                      aria-label="Confirmar novo nome"
                      onClick={() => confirmRename(item.id)}
                      className="rounded-lg p-2 text-emerald-600 hover:bg-emerald-500/10"
                    >
                      <Check className="h-4 w-4" />
                    </button>
                    <button
                      aria-label="Cancelar"
                      onClick={() => setEditingId(null)}
                      className="rounded-lg p-2 text-red-600 hover:bg-red-500/10"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate font-medium">{item.title}</p>
                      <Badge>{historyTypeLabel(item.type)}</Badge>
                    </div>
                    <p className="mt-1 truncate text-sm text-[var(--color-text-muted)]">
                      {item.preview}
                    </p>
                    <p className="mt-1 text-xs text-[var(--color-text-muted)]">
                      {formatDate(item.createdAt)}
                    </p>
                  </>
                )}
              </div>
              {editingId !== item.id && (
                <div className="flex shrink-0 gap-1">
                  <button
                    aria-label={`Renomear ${item.title}`}
                    onClick={() => startRename(item)}
                    className="rounded-lg p-2.5 text-[var(--color-text-muted)] hover:bg-[var(--color-bg-subtle)] hover:text-[var(--color-primary)]"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    aria-label={`Compartilhar ${item.title}`}
                    onClick={() => handleShare(item)}
                    className="rounded-lg p-2.5 text-[var(--color-text-muted)] hover:bg-[var(--color-bg-subtle)] hover:text-[var(--color-primary)]"
                  >
                    <Share2 className="h-4 w-4" />
                  </button>
                  <button
                    aria-label={`Excluir ${item.title}`}
                    onClick={() => handleDelete(item.id)}
                    className="rounded-lg p-2.5 text-[var(--color-text-muted)] hover:bg-red-500/10 hover:text-red-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              )}
            </Card>
          ))}
        </div>
      </Container>
    </>
  );
}
