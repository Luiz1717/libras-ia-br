import type { MetadataRoute } from "next";

const BASE_URL = "https://aponteia.exemplo.com.br";

const ROUTES = [
  "",
  "/ia",
  "/libras",
  "/legendas",
  "/ferramentas",
  "/voz-para-texto",
  "/texto-para-voz",
  "/ocr",
  "/educacao",
  "/sobre",
  "/acessibilidade",
  "/privacidade",
  "/contribuir",
  "/entrar",
  "/cadastro",
];

export default function sitemap(): MetadataRoute.Sitemap {
  return ROUTES.map((route) => ({
    url: `${BASE_URL}${route}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: route === "" ? 1 : 0.7,
  }));
}
