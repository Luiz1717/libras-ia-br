"use client";

import { useState } from "react";
import { Mic, Pause, Play, Square, Copy, Save, Trash2, Check } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useSpeechRecognition } from "@/lib/useSpeechRecognition";
import { addHistoryItem } from "@/lib/history";

export function VozParaTextoClient() {
  const {
    supported,
    listening,
    finalText,
    interimText,
    error,
    start,
    stop,
    reset,
    setFinalText,
  } = useSpeechRecognition();
  const [paused, setPaused] = useState(false);
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const hasStarted = listening || finalText.length > 0 || paused;

  function handleStart() {
    setPaused(false);
    start();
  }

  function handlePause() {
    stop();
    setPaused(true);
  }

  function handleResume() {
    setPaused(false);
    start();
  }

  function handleFinish() {
    stop();
    setPaused(false);
  }

  function handleClear() {
    stop();
    setPaused(false);
    reset();
    setFinalText("");
    setSaved(false);
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(finalText.trim());
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard indisponível
    }
  }

  function handleSave() {
    if (!finalText.trim()) return;
    addHistoryItem({
      type: "transcricao",
      title: finalText.trim().slice(0, 60) || "Transcrição de voz",
      preview: finalText.trim().slice(0, 140),
    });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2500);
  }

  return (
    <>
      <PageHeader
        eyebrow="Ferramenta"
        title="Fala → Texto"
        description="Fale perto do microfone do seu dispositivo e veja a transcrição aparecer em tempo real."
      />
      <Container className="py-10 sm:py-14">
        {!supported && (
          <Card className="mb-6 border-amber-500/40 bg-amber-500/10 text-amber-900 dark:text-amber-300">
            Seu navegador não é compatível com reconhecimento de fala. Tente usar o Google
            Chrome em um computador ou celular Android.
          </Card>
        )}
        {error && (
          <Card className="mb-6 border-red-500/40 bg-red-500/10 text-red-700 dark:text-red-400">
            {error}
          </Card>
        )}

        <Card className="flex flex-col items-center gap-6 py-12 text-center">
          <span
            role="status"
            aria-live="polite"
            className="text-lg font-semibold text-[var(--color-text-muted)]"
          >
            {listening ? "Ouvindo…" : paused ? "Pausado" : "Pronto para ouvir"}
          </span>

          <button
            type="button"
            onClick={listening ? handlePause : handleStart}
            disabled={!supported}
            aria-label={listening ? "Pausar gravação" : "Iniciar gravação"}
            className={`flex h-28 w-28 items-center justify-center rounded-full text-white shadow-lg transition-transform active:scale-95 disabled:opacity-40 ${
              listening
                ? "bg-red-500 animate-pulse-soft"
                : "bg-[var(--color-primary)] hover:bg-[var(--color-primary-hover)]"
            }`}
          >
            <Mic className="h-12 w-12" />
          </button>
          <p className="text-sm text-[var(--color-text-muted)]">
            {listening ? "Toque para pausar" : "Toque para começar"}
          </p>

          <div className="flex flex-wrap justify-center gap-2">
            {!listening && paused && (
              <Button variant="outline" size="sm" onClick={handleResume}>
                <Play className="h-4 w-4" /> Continuar
              </Button>
            )}
            {listening && (
              <Button variant="outline" size="sm" onClick={handlePause}>
                <Pause className="h-4 w-4" /> Pausar
              </Button>
            )}
            <Button variant="outline" size="sm" onClick={handleFinish} disabled={!hasStarted}>
              <Square className="h-4 w-4" /> Finalizar
            </Button>
          </div>
        </Card>

        <Card className="mt-6">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Transcrição</h2>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={handleCopy} disabled={!finalText.trim()}>
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copiado" : "Copiar"}
              </Button>
              <Button variant="ghost" size="sm" onClick={handleSave} disabled={!finalText.trim()}>
                {saved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
                {saved ? "Salvo" : "Salvar"}
              </Button>
              <Button variant="ghost" size="sm" onClick={handleClear} disabled={!finalText.trim() && !hasStarted}>
                <Trash2 className="h-4 w-4" /> Limpar
              </Button>
            </div>
          </div>
          <div
            className="mt-4 min-h-[160px] whitespace-pre-wrap rounded-xl border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-4 text-lg leading-relaxed"
            aria-live="polite"
          >
            {finalText || interimText ? (
              <>
                {finalText}
                <span className="text-[var(--color-text-muted)]">{interimText}</span>
              </>
            ) : (
              <span className="text-[var(--color-text-muted)]">
                O texto transcrito vai aparecer aqui.
              </span>
            )}
          </div>
        </Card>
      </Container>
    </>
  );
}
