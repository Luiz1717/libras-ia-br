import type { Metadata } from "next";
import { VozParaTextoClient } from "./VozParaTextoClient";

export const metadata: Metadata = {
  title: "Fala → Texto",
  description:
    "Transcreva fala em texto em tempo real, direto do navegador, em português brasileiro.",
};

export default function Page() {
  return <VozParaTextoClient />;
}
