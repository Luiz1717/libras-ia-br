import type { Metadata } from "next";
import { LegendasClient } from "./LegendasClient";

export const metadata: Metadata = {
  title: "Vídeo → Legenda",
  description:
    "Ferramenta profissional para gerar, editar e exportar legendas automáticas em SRT e VTT.",
};

export default function Page() {
  return <LegendasClient />;
}
