"use client";

import { useEffect, useRef, useState } from "react";
import { UploadCloud, Download, Trash2, Plus } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { StatusBadge } from "@/components/ui/StatusBadge";
import {
  DEFAULT_SUBTITLE_STYLE,
  downloadTextFile,
  formatClock,
  generateMockCues,
  generateSrt,
  generateVtt,
  type SubtitleAlign,
  type SubtitleCue,
  type SubtitlePosition,
  type SubtitleStyle,
} from "@/lib/subtitles";
import { addHistoryItem } from "@/lib/history";

type Step = "upload" | "processando" | "editor";

const PROCESSING_STAGES = [
  "Enviando vídeo…",
  "Analisando áudio…",
  "Transcrevendo fala…",
  "Sincronizando legendas…",
];

const POSITION_LABEL: Record<SubtitlePosition, string> = {
  topo: "Topo",
  centro: "Centro",
  rodape: "Rodapé",
};
const ALIGN_LABEL: Record<SubtitleAlign, string> = {
  esquerda: "Esquerda",
  centro: "Centro",
  direita: "Direita",
};

export function LegendasClient() {
  const [step, setStep] = useState<Step>("upload");
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState("");
  const [stageIndex, setStageIndex] = useState(0);
  const [cues, setCues] = useState<SubtitleCue[]>([]);
  const [style, setStyle] = useState<SubtitleStyle>(DEFAULT_SUBTITLE_STYLE);
  const [currentTime, setCurrentTime] = useState(0);
  const [dragOver, setDragOver] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (step !== "processando") return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setStageIndex(0);
    const interval = window.setInterval(() => {
      setStageIndex((i) => Math.min(i + 1, PROCESSING_STAGES.length - 1));
    }, 750);
    return () => window.clearInterval(interval);
  }, [step]);

  function handleFile(file: File) {
    const url = URL.createObjectURL(file);
    setVideoUrl(url);
    setFileName(file.name);
    setStep("processando");

    const probe = document.createElement("video");
    probe.preload = "metadata";
    probe.src = url;
    probe.onloadedmetadata = () => {
      const duration = Number.isFinite(probe.duration) ? probe.duration : 30;
      window.setTimeout(() => {
        const generated = generateMockCues(duration);
        setCues(generated);
        setStep("editor");
        addHistoryItem({
          type: "legenda",
          title: file.name,
          preview: `Legenda gerada automaticamente com ${generated.length} trechos.`,
        });
      }, PROCESSING_STAGES.length * 750 + 300);
    };
  }

  function onInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }

  function onDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  }

  function updateCue(id: string, patch: Partial<SubtitleCue>) {
    setCues((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
  }

  function removeCue(id: string) {
    setCues((prev) => prev.filter((c) => c.id !== id));
  }

  function addCue() {
    const last = cues[cues.length - 1];
    const start = last ? last.end + 0.2 : 0;
    setCues((prev) => [
      ...prev,
      { id: `cue-${Date.now()}`, start, end: start + 2, text: "Nova legenda" },
    ]);
  }

  const activeCue = cues.find((c) => currentTime >= c.start && currentTime <= c.end);

  const positionClass: Record<SubtitlePosition, string> = {
    topo: "top-4",
    centro: "top-1/2 -translate-y-1/2",
    rodape: "bottom-4",
  };
  const alignClass: Record<SubtitleAlign, string> = {
    esquerda: "text-left items-start",
    centro: "text-center items-center",
    direita: "text-right items-end",
  };

  return (
    <>
      <PageHeader
        eyebrow="Ferramenta profissional"
        title="Vídeo → Legenda"
        description="Envie um vídeo, gere legendas automaticamente e edite texto, tempo e estilo antes de exportar."
      />
      <Container className="py-10 sm:py-14">
        {step === "upload" && (
          <Card>
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              className={`flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-14 text-center transition-colors ${
                dragOver ? "border-[var(--color-primary)] bg-[var(--color-primary)]/5" : "border-[var(--color-border)]"
              }`}
            >
              <UploadCloud className="h-10 w-10 text-[var(--color-text-muted)]" aria-hidden="true" />
              <p className="font-medium">Arraste um vídeo aqui</p>
              <p className="text-sm text-[var(--color-text-muted)]">
                Formatos comuns como MP4, WebM e MOV são aceitos.
              </p>
              <Button size="sm" onClick={() => fileInputRef.current?.click()}>
                Selecionar vídeo
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={onInputChange}
              />
            </div>
          </Card>
        )}

        {step === "processando" && (
          <Card className="flex flex-col items-center gap-4 py-16 text-center">
            <StatusBadge state="processando" label={PROCESSING_STAGES[stageIndex]} />
            <p className="max-w-md text-sm text-[var(--color-text-muted)]">
              Estamos processando <strong>{fileName}</strong>. Você pode continuar navegando
              enquanto isso — vamos avisar quando a legenda estiver pronta.
            </p>
            <div className="h-2 w-64 overflow-hidden rounded-full bg-[var(--color-bg-subtle)]">
              <div
                className="h-full rounded-full bg-[var(--color-primary)] transition-all"
                style={{ width: `${((stageIndex + 1) / PROCESSING_STAGES.length) * 100}%` }}
              />
            </div>
          </Card>
        )}

        {step === "editor" && videoUrl && (
          <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <Card className="p-3">
                <div className="relative overflow-hidden rounded-xl bg-black">
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    controls
                    className="max-h-[420px] w-full"
                    onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                  />
                  {activeCue && (
                    <div
                      className={`pointer-events-none absolute inset-x-0 flex px-6 ${positionClass[style.position]} ${alignClass[style.align]}`}
                    >
                      <span
                        style={{
                          fontFamily: style.font,
                          fontSize: `${style.size}px`,
                        }}
                        className={`inline-block max-w-full rounded-md px-3 py-1.5 text-white ${
                          style.background ? "bg-black/70" : ""
                        }`}
                      >
                        {activeCue.text}
                      </span>
                    </div>
                  )}
                </div>
              </Card>

              <Card className="mt-6">
                <h2 className="font-semibold">Estilo da legenda</h2>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="font" className="mb-1.5 block text-sm font-medium">
                      Fonte
                    </label>
                    <select
                      id="font"
                      value={style.font}
                      onChange={(e) => setStyle((s) => ({ ...s, font: e.target.value }))}
                      className="w-full rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-2.5 text-sm outline-none focus:border-[var(--color-primary)]"
                    >
                      <option value="Sans-serif">Sem serifa</option>
                      <option value="Serif">Serifada</option>
                      <option value="monospace">Monoespaçada</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="size" className="mb-1.5 flex justify-between text-sm font-medium">
                      Tamanho <span className="text-[var(--color-text-muted)]">{style.size}px</span>
                    </label>
                    <input
                      id="size"
                      type="range"
                      min={14}
                      max={36}
                      value={style.size}
                      onChange={(e) => setStyle((s) => ({ ...s, size: Number(e.target.value) }))}
                      className="w-full accent-[var(--color-primary)]"
                    />
                  </div>
                  <div>
                    <label htmlFor="position" className="mb-1.5 block text-sm font-medium">
                      Posição
                    </label>
                    <select
                      id="position"
                      value={style.position}
                      onChange={(e) =>
                        setStyle((s) => ({ ...s, position: e.target.value as SubtitlePosition }))
                      }
                      className="w-full rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-2.5 text-sm outline-none focus:border-[var(--color-primary)]"
                    >
                      {Object.entries(POSITION_LABEL).map(([v, l]) => (
                        <option key={v} value={v}>{l}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="align" className="mb-1.5 block text-sm font-medium">
                      Alinhamento
                    </label>
                    <select
                      id="align"
                      value={style.align}
                      onChange={(e) => setStyle((s) => ({ ...s, align: e.target.value as SubtitleAlign }))}
                      className="w-full rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-2.5 text-sm outline-none focus:border-[var(--color-primary)]"
                    >
                      {Object.entries(ALIGN_LABEL).map(([v, l]) => (
                        <option key={v} value={v}>{l}</option>
                      ))}
                    </select>
                  </div>
                  <label className="flex items-center gap-2 text-sm font-medium sm:col-span-2">
                    <input
                      type="checkbox"
                      checked={style.background}
                      onChange={(e) => setStyle((s) => ({ ...s, background: e.target.checked }))}
                      className="h-4 w-4 accent-[var(--color-primary)]"
                    />
                    Fundo escuro atrás do texto
                  </label>
                </div>
              </Card>

              <Card className="mt-6">
                <h2 className="font-semibold">Exportar</h2>
                <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                  Baixe os arquivos de legenda prontos para usar em players de vídeo.
                </p>
                <div className="mt-4 flex flex-wrap gap-3">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => downloadTextFile(`${fileName || "legenda"}.srt`, generateSrt(cues), "text/plain")}
                  >
                    <Download className="h-4 w-4" /> Exportar SRT
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => downloadTextFile(`${fileName || "legenda"}.vtt`, generateVtt(cues), "text/vtt")}
                  >
                    <Download className="h-4 w-4" /> Exportar VTT
                  </Button>
                </div>
                <p className="mt-3 text-xs text-[var(--color-text-muted)]">
                  A exportação de vídeo com legenda já incorporada está planejada para uma
                  versão futura, que exige processamento em servidor.
                </p>
              </Card>
            </div>

            <Card>
              <div className="flex items-center justify-between">
                <h2 className="font-semibold">Editor de legendas</h2>
                <Button size="sm" variant="ghost" onClick={addCue}>
                  <Plus className="h-4 w-4" /> Adicionar trecho
                </Button>
              </div>
              <ul className="mt-4 flex max-h-[560px] flex-col gap-3 overflow-y-auto scrollbar-thin pr-1">
                {cues.map((cue) => (
                  <li
                    key={cue.id}
                    className={`rounded-xl border-2 p-3 ${
                      activeCue?.id === cue.id
                        ? "border-[var(--color-primary)]"
                        : "border-[var(--color-border)]"
                    }`}
                  >
                    <div className="flex items-center gap-2 text-xs text-[var(--color-text-muted)]">
                      <label className="flex items-center gap-1">
                        Início
                        <input
                          type="number"
                          step={0.1}
                          value={cue.start}
                          onChange={(e) => updateCue(cue.id, { start: Number(e.target.value) })}
                          className="w-16 rounded-md border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-1.5 py-1"
                        />
                      </label>
                      <label className="flex items-center gap-1">
                        Fim
                        <input
                          type="number"
                          step={0.1}
                          value={cue.end}
                          onChange={(e) => updateCue(cue.id, { end: Number(e.target.value) })}
                          className="w-16 rounded-md border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-1.5 py-1"
                        />
                      </label>
                      <span>
                        ({formatClock(cue.start)}–{formatClock(cue.end)})
                      </span>
                      <button
                        onClick={() => removeCue(cue.id)}
                        aria-label="Remover trecho"
                        className="ml-auto rounded-md p-1 hover:bg-red-500/10 hover:text-red-600"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <label htmlFor={`text-${cue.id}`} className="sr-only">
                      Texto da legenda
                    </label>
                    <textarea
                      id={`text-${cue.id}`}
                      rows={2}
                      value={cue.text}
                      onChange={(e) => updateCue(cue.id, { text: e.target.value })}
                      className="mt-2 w-full resize-none rounded-lg border border-[var(--color-border)] bg-[var(--color-bg)] p-2 text-sm outline-none focus:border-[var(--color-primary)]"
                    />
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        )}
      </Container>
    </>
  );
}
