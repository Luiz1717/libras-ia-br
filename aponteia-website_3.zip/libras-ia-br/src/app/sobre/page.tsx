import type { Metadata } from "next";
import { Users, Target, Heart, Layers } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { ButtonLink } from "@/components/ui/Button";

export const metadata: Metadata = {
  title: "Sobre",
  description:
    "Conheça a missão do AponteIA: tecnologia assistiva criada com e para a comunidade surda brasileira.",
};

export default function SobrePage() {
  return (
    <>
      <PageHeader
        eyebrow="O projeto"
        title="Sobre o AponteIA"
        description="Tecnologia que aproxima pessoas. Inteligência Artificial que amplia a acessibilidade."
      />
      <Container className="py-10 sm:py-14">
        <div className="grid gap-10 lg:grid-cols-[1.3fr_1fr]">
          <div className="flex flex-col gap-8">
            <section>
              <h2 className="text-2xl font-bold">Por que o projeto existe?</h2>
              <p className="mt-3 leading-relaxed text-[var(--color-text-muted)]">
                A comunidade surda ainda enfrenta barreiras no acesso à informação, à
                comunicação e a serviços — na escola, no trabalho, na saúde e em situações do
                dia a dia. A tecnologia por si só não resolve essas barreiras, mas pode ajudar
                a reduzi-las quando é construída com a participação de quem vive essa
                realidade.
              </p>
            </section>
            <section>
              <h2 className="text-2xl font-bold">Nossa missão</h2>
              <p className="mt-3 leading-relaxed text-[var(--color-text-muted)]">
                Criar soluções digitais acessíveis utilizando inteligência artificial, Libras
                e tecnologias assistivas — priorizando sempre a autonomia da pessoa surda, e
                não apenas a adaptação posterior de um produto já pronto.
              </p>
            </section>
            <section>
              <h2 className="text-2xl font-bold">O que nos guia</h2>
              <p className="mt-3 leading-relaxed text-[var(--color-text-muted)]">
                Valorizamos Libras, cultura surda, identidade e autonomia. Não tratamos a
                surdez apenas como uma limitação a ser corrigida, mas como parte de uma
                experiência e uma cultura que merece tecnologia pensada para ela desde o
                início — não adaptada depois.
              </p>
            </section>
            <section>
              <h2 className="text-2xl font-bold">Um limite importante sobre Libras</h2>
              <p className="mt-3 leading-relaxed text-[var(--color-text-muted)]">
                Libras é uma língua natural, com gramática própria, estrutura espacial,
                variações regionais, contexto e expressões não manuais. Nenhuma IA hoje
                traduz Libras com perfeição. Por isso, todas as funcionalidades de IA
                relacionadas a Libras nesta plataforma são desenvolvidas e avaliadas com a
                participação de pessoas fluentes em Libras e especialistas — e são
                claramente identificadas como experimentais.
              </p>
            </section>
          </div>

          <div className="flex flex-col gap-4">
            <Card className="flex items-start gap-3">
              <Users className="h-6 w-6 shrink-0 text-[var(--color-primary)]" aria-hidden="true" />
              <div>
                <h3 className="font-semibold">Feito com a comunidade</h3>
                <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                  Pessoas surdas participam dos testes e da validação de cada
                  funcionalidade, desde a concepção.
                </p>
              </div>
            </Card>
            <Card className="flex items-start gap-3">
              <Target className="h-6 w-6 shrink-0 text-[var(--color-primary)]" aria-hidden="true" />
              <div>
                <h3 className="font-semibold">Autonomia acima de tudo</h3>
                <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                  A IA não substitui a comunidade surda — ela é uma ferramenta a serviço da
                  autonomia das pessoas.
                </p>
              </div>
            </Card>
            <Card className="flex items-start gap-3">
              <Layers className="h-6 w-6 shrink-0 text-[var(--color-primary)]" aria-hidden="true" />
              <div>
                <h3 className="font-semibold">Construção incremental</h3>
                <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                  Começamos por um MVP focado e evoluímos com cuidado, priorizando
                  segurança, privacidade e qualidade sobre velocidade.
                </p>
              </div>
            </Card>
            <Card className="flex items-start gap-3">
              <Heart className="h-6 w-6 shrink-0 text-[var(--color-primary)]" aria-hidden="true" />
              <div>
                <h3 className="font-semibold">Um projeto brasileiro</h3>
                <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                  Pensado para a realidade e a língua da comunidade surda brasileira.
                </p>
              </div>
            </Card>
            <ButtonLink href="/contribuir" variant="outline" fullWidth>
              Faça parte do projeto
            </ButtonLink>
          </div>
        </div>
      </Container>
    </>
  );
}
