import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "AponteIA — IA para acessibilidade e Libras",
    short_name: "AponteIA",
    description:
      "Plataforma brasileira de tecnologia assistiva com IA: Libras, legendas, voz, texto e OCR.",
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#1857c9",
    lang: "pt-BR",
    orientation: "portrait-primary",
    categories: ["accessibility", "education", "utilities"],
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
