import type { Metadata } from "next";
import { AdminLibrasClient } from "./AdminLibrasClient";

export const metadata: Metadata = {
  title: "Gerenciar sinais de Libras",
  description: "Cadastre sinais de Libras com vídeo e exporte um pacote pronto para publicar.",
  robots: { index: false, follow: false },
};

export default function Page() {
  return <AdminLibrasClient />;
}
