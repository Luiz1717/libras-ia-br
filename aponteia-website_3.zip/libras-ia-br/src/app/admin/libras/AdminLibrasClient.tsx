"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Upload,
  Play,
  Pencil,
  Trash2,
  Download,
  FileArchive,
  Video,
  Database,
  X,
  Check,
  Loader2,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, Badge } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Field } from "@/components/ui/Field";
import {
  listDrafts,
  saveDraft,
  deleteDraft,
  clearDrafts,
  slugify,
  type SignDraft,
  type DraftStatus,
} from "@/lib/signsDb";
import { buildCsv, buildExportZip, captureVideoFrame, downloadBlob } from "@/lib/signsExport";
import { SIGN_CATEGORIES } from "@/lib/libras-data";

const BASE_URL_STORAGE_KEY = "libras-ia:admin-base-url";

const EMPTY_FORM = {
  id: "",
  word: "",
  category: SIGN_CATEGORIES[0] ?? "Tecnologia",
  description: "",
  example: "",
  region: "Uso nacional",
  status: "em_revisao" as DraftStatus,
};

/** Miniatura de um rascunho salvo — cria o object URL do poster uma única
 * vez por blob e libera a memória ao desmontar/trocar de blob. */
function DraftThumbnail({ blob }: { blob: Blob }) {
  const url = useMemo(() => URL.createObjectURL(blob), [blob]);

  // Libera o object URL quando o blob muda ou o componente desmonta —
  // não é setState, só limpeza de um recurso externo do navegador.
  useEffect(() => {
    return () => URL.revokeObjectURL(url);
  }, [url]);

  // eslint-disable-next-line @next/next/no-img-element
  return <img src={url} alt="" className="h-full w-full object-cover" />;
}

export function AdminLibrasClient() {
  const [drafts, setDrafts] = useState<SignDraft[]>([]);
  const [loadingDrafts, setLoadingDrafts] = useState(true);
  const [form, setForm] = useState(EMPTY_FORM);
  const [idTouched, setIdTouched] = useState(false);
  const [editingOriginalId, setEditingOriginalId] = useState<string | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [posterBlob, setPosterBlob] = useState<Blob | null>(null);
  const [capturingPoster, setCapturingPoster] = useState(false);
  const [keepExistingVideo, setKeepExistingVideo] = useState(false);
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);
  const [savedFlash, setSavedFlash] = useState(false);
  const [previewingId, setPreviewingId] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [baseUrl, setBaseUrl] = useState("");
  const [exporting, setExporting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    refreshDrafts();
    try {
      const saved = window.localStorage.getItem(BASE_URL_STORAGE_KEY);
      // Leitura do localStorage só é possível no cliente, após montar —
      // não dá para saber esse valor durante a renderização no servidor.
      // eslint-disable-next-line react-hooks/set-state-in-effect
      if (saved) setBaseUrl(saved);
    } catch {
      // ignora
    }
  }, []);

  async function refreshDrafts() {
    setLoadingDrafts(true);
    const all = await listDrafts();
    setDrafts(all);
    setLoadingDrafts(false);
  }

  function handleBaseUrlChange(value: string) {
    setBaseUrl(value);
    try {
      window.localStorage.setItem(BASE_URL_STORAGE_KEY, value);
    } catch {
      // ignora
    }
  }

  function resetForm() {
    setForm(EMPTY_FORM);
    setIdTouched(false);
    setEditingOriginalId(null);
    setVideoFile(null);
    setVideoPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return null;
    });
    setPosterBlob(null);
    setKeepExistingVideo(false);
    setFormError("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  function handleWordChange(value: string) {
    setForm((f) => ({
      ...f,
      word: value,
      id: idTouched ? f.id : slugify(value),
    }));
  }

  async function handleVideoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setVideoFile(file);
    setKeepExistingVideo(false);
    setVideoPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(file);
    });
    setCapturingPoster(true);
    const frame = await captureVideoFrame(file);
    setPosterBlob(frame);
    setCapturingPoster(false);
  }

  function startEdit(draft: SignDraft) {
    setForm({
      id: draft.id,
      word: draft.word,
      category: draft.category,
      description: draft.description,
      example: draft.example,
      region: draft.region,
      status: draft.status,
    });
    setIdTouched(true);
    setEditingOriginalId(draft.id);
    setVideoFile(null);
    setVideoPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return null;
    });
    setPosterBlob(draft.posterBlob ?? null);
    setKeepExistingVideo(!!draft.videoBlob);
    setFormError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setFormError("");

    if (!form.word.trim() || !form.category.trim() || !form.description.trim() || !form.example.trim()) {
      setFormError("Preencha palavra, categoria, descrição e exemplo.");
      return;
    }
    if (!form.id.trim()) {
      setFormError("O identificador (id) não pode ficar vazio.");
      return;
    }
    const duplicate = drafts.find((d) => d.id === form.id && d.id !== editingOriginalId);
    if (duplicate) {
      setFormError(`Já existe um sinal salvo com o id "${form.id}". Escolha outro.`);
      return;
    }

    setSaving(true);

    const existing = editingOriginalId ? drafts.find((d) => d.id === editingOriginalId) : undefined;

    const draft: SignDraft = {
      id: form.id.trim(),
      word: form.word.trim(),
      category: form.category.trim(),
      description: form.description.trim(),
      example: form.example.trim(),
      region: form.region.trim() || "Uso nacional",
      status: form.status,
      videoBlob: videoFile ?? (keepExistingVideo ? existing?.videoBlob : undefined),
      videoName: videoFile?.name ?? (keepExistingVideo ? existing?.videoName : undefined),
      posterBlob: posterBlob ?? (keepExistingVideo ? existing?.posterBlob : undefined),
      posterName: posterBlob ? `${form.id.trim()}.jpg` : existing?.posterName,
      updatedAt: new Date().toISOString().slice(0, 10),
    };

    // Se o id mudou durante uma edição, remove o registro antigo.
    if (editingOriginalId && editingOriginalId !== draft.id) {
      await deleteDraft(editingOriginalId);
    }

    await saveDraft(draft);
    await refreshDrafts();
    setSaving(false);
    setSavedFlash(true);
    window.setTimeout(() => setSavedFlash(false), 2000);
    resetForm();
  }

  async function handleDelete(id: string) {
    await deleteDraft(id);
    if (previewingId === id) closePreview();
    await refreshDrafts();
  }

  function openPreview(draft: SignDraft) {
    if (!draft.videoBlob) return;
    setPreviewingId(draft.id);
    setPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(draft.videoBlob!);
    });
  }

  function closePreview() {
    setPreviewingId(null);
    setPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return null;
    });
  }

  async function handleClearAll() {
    await clearDrafts();
    await refreshDrafts();
    setConfirmClear(false);
    resetForm();
  }

  async function handleExportZip() {
    setExporting(true);
    try {
      const blob = await buildExportZip(drafts, baseUrl);
      downloadBlob(blob, "sinais-libras-pacote.zip");
    } finally {
      setExporting(false);
    }
  }

  function handleExportCsvOnly() {
    const csv = buildCsv(drafts, baseUrl);
    downloadBlob(new Blob([csv], { type: "text/csv;charset=utf-8" }), "sinais-libras.csv");
  }

  const comVideo = drafts.filter((d) => d.videoBlob).length;

  return (
    <>
      <PageHeader
        eyebrow="Painel administrativo"
        title="Gerenciar sinais de Libras"
        description="Cadastre sinais com vídeo, revise a pré-visualização e exporte um pacote pronto para publicar no dicionário do site."
      />
      <Container className="py-10 sm:py-14">
        <Card className="mb-6 flex items-start gap-3 border-[var(--color-primary)]/30 bg-[var(--color-primary)]/5">
          <Database className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-primary)]" aria-hidden="true" />
          <p className="text-sm leading-relaxed">
            Isso salva os sinais em um banco de dados local do seu navegador (IndexedDB) —
            funciona offline e nada é enviado a nenhum servidor. Quando terminar, use
            &ldquo;Baixar pacote&rdquo; para gerar um .zip com os vídeos e o CSV prontos.
            Depois é só subir os vídeos para o seu armazenamento (Cloudflare R2, S3 etc.) e
            substituir <code>content/sinais-libras.csv</code> no projeto — o README explica
            o passo a passo completo.
          </p>
        </Card>

        <Card>
          <h2 className="font-semibold">{editingOriginalId ? "Editar sinal" : "Novo sinal"}</h2>
          <form onSubmit={handleSave} className="mt-4 grid gap-4 lg:grid-cols-2">
            <div className="flex flex-col gap-4">
              <Field
                id="word"
                label="Palavra"
                value={form.word}
                onChange={(e) => handleWordChange(e.target.value)}
                placeholder="Ex.: Computador"
              />
              <Field
                id="sign-id"
                label="Identificador (id)"
                value={form.id}
                onChange={(e) => {
                  setIdTouched(true);
                  setForm((f) => ({ ...f, id: e.target.value }));
                }}
                hint="Gerado automaticamente a partir da palavra — pode editar se quiser."
              />
              <div className="flex flex-col gap-1.5">
                <label htmlFor="category" className="text-sm font-medium">
                  Categoria
                </label>
                <select
                  id="category"
                  value={form.category}
                  onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                  className="rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg)] px-4 py-2.5 outline-none focus:border-[var(--color-primary)]"
                >
                  {SIGN_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <Field
                id="region"
                label="Região / variação"
                value={form.region}
                onChange={(e) => setForm((f) => ({ ...f, region: e.target.value }))}
                placeholder="Uso nacional"
              />
              <div className="flex flex-col gap-1.5">
                <label htmlFor="status" className="text-sm font-medium">
                  Status de revisão
                </label>
                <select
                  id="status"
                  value={form.status}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, status: e.target.value as DraftStatus }))
                  }
                  className="rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg)] px-4 py-2.5 outline-none focus:border-[var(--color-primary)]"
                >
                  <option value="em_revisao">Em revisão</option>
                  <option value="revisado">Revisado por pessoa surda/linguista</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <label htmlFor="description" className="text-sm font-medium">
                  Descrição do sinal
                </label>
                <textarea
                  id="description"
                  rows={3}
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  placeholder="Como as mãos e o movimento formam o sinal…"
                  className="resize-y rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg)] px-4 py-2.5 outline-none focus:border-[var(--color-primary)]"
                />
              </div>
              <Field
                id="example"
                label="Frase de exemplo"
                value={form.example}
                onChange={(e) => setForm((f) => ({ ...f, example: e.target.value }))}
                placeholder="Ex.: Preciso usar o computador."
              />

              <div className="flex flex-col gap-1.5">
                <label htmlFor="video" className="text-sm font-medium">
                  Vídeo do sinal
                </label>
                <input
                  ref={fileInputRef}
                  id="video"
                  type="file"
                  accept="video/*"
                  onChange={handleVideoChange}
                  className="rounded-xl border-2 border-dashed border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-4 py-3 text-sm file:mr-3 file:rounded-full file:border-0 file:bg-[var(--color-primary)] file:px-3 file:py-1.5 file:text-sm file:font-semibold file:text-[var(--color-primary-contrast)]"
                />
                {keepExistingVideo && !videoFile && (
                  <p className="text-xs text-[var(--color-text-muted)]">
                    Mantendo o vídeo já salvo para este sinal. Escolha outro arquivo para
                    substituir.
                  </p>
                )}
                {(videoPreviewUrl || (keepExistingVideo && editingOriginalId)) && (
                  <div className="mt-2 overflow-hidden rounded-xl bg-black">
                    {videoPreviewUrl ? (
                      <video src={videoPreviewUrl} controls className="max-h-56 w-full" />
                    ) : (
                      <p className="p-3 text-center text-xs text-white/70">
                        (pré-visualização do vídeo já salvo aparece ao reabrir o arquivo)
                      </p>
                    )}
                  </div>
                )}
                {capturingPoster && (
                  <p className="flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                    Gerando miniatura a partir do vídeo…
                  </p>
                )}
              </div>
            </div>

            {formError && (
              <p role="alert" className="lg:col-span-2 text-sm font-medium text-red-600 dark:text-red-400">
                {formError}
              </p>
            )}

            <div className="flex flex-wrap gap-3 lg:col-span-2">
              <Button type="submit" disabled={saving}>
                {savedFlash ? <Check className="h-4 w-4" /> : <Upload className="h-4 w-4" />}
                {saving ? "Salvando…" : savedFlash ? "Salvo" : editingOriginalId ? "Salvar alterações" : "Salvar sinal"}
              </Button>
              {editingOriginalId && (
                <Button type="button" variant="ghost" onClick={resetForm}>
                  Cancelar edição
                </Button>
              )}
            </div>
          </form>
        </Card>

        <Card className="mt-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="font-semibold">
              Sinais salvos localmente ({drafts.length})
            </h2>
            <p className="text-sm text-[var(--color-text-muted)]">{comVideo} com vídeo</p>
          </div>

          {loadingDrafts ? (
            <p className="mt-4 text-sm text-[var(--color-text-muted)]">Carregando…</p>
          ) : drafts.length === 0 ? (
            <p className="mt-4 text-sm text-[var(--color-text-muted)]">
              Nenhum sinal salvo ainda. Preencha o formulário acima para começar.
            </p>
          ) : (
            <ul className="mt-4 flex flex-col gap-3">
              {drafts.map((draft) => (
                <li
                  key={draft.id}
                  className="flex flex-col gap-3 rounded-xl border border-[var(--color-border)] p-3 sm:flex-row sm:items-center"
                >
                  <div className="flex h-16 w-24 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-[var(--color-bg-subtle)]">
                    {draft.posterBlob ? (
                      <DraftThumbnail blob={draft.posterBlob} />
                    ) : (
                      <Video className="h-6 w-6 text-[var(--color-text-muted)]" aria-hidden="true" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-medium">{draft.word}</p>
                      <Badge tone="primary">{draft.category}</Badge>
                      <Badge tone={draft.status === "revisado" ? "success" : "warning"}>
                        {draft.status === "revisado" ? "Revisado" : "Em revisão"}
                      </Badge>
                      {!draft.videoBlob && <Badge>Sem vídeo</Badge>}
                    </div>
                    <p className="mt-1 truncate text-sm text-[var(--color-text-muted)]">
                      id: {draft.id}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-1.5">
                    {draft.videoBlob && (
                      <Button size="sm" variant="ghost" onClick={() => openPreview(draft)}>
                        <Play className="h-4 w-4" /> Ver
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => startEdit(draft)}>
                      <Pencil className="h-4 w-4" /> Editar
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(draft.id)}>
                      <Trash2 className="h-4 w-4" /> Excluir
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}

          {!confirmClear ? (
            drafts.length > 0 && (
              <button
                onClick={() => setConfirmClear(true)}
                className="mt-4 text-xs font-medium text-red-600 hover:underline dark:text-red-400"
              >
                Limpar todos os sinais salvos localmente
              </button>
            )
          ) : (
            <div className="mt-4 rounded-xl border border-red-500/40 bg-red-500/10 p-3">
              <p className="text-sm text-red-700 dark:text-red-400">
                Isso apaga todos os {drafts.length} sinais salvos neste navegador. Não afeta
                o dicionário já publicado no site. Confirma?
              </p>
              <div className="mt-2 flex gap-2">
                <Button size="sm" variant="danger" onClick={handleClearAll}>
                  Sim, limpar tudo
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setConfirmClear(false)}>
                  Cancelar
                </Button>
              </div>
            </div>
          )}
        </Card>

        <Card className="mt-6">
          <h2 className="font-semibold">Exportar pacote</h2>
          <div className="mt-3 max-w-md">
            <Field
              id="base-url"
              label="URL base onde os vídeos vão ficar hospedados"
              value={baseUrl}
              onChange={(e) => handleBaseUrlChange(e.target.value)}
              placeholder="https://cdn.seusite.com/sinais"
              hint="Usada para preencher videoUrl/posterUrl no CSV exportado."
            />
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            <Button onClick={handleExportZip} disabled={drafts.length === 0 || exporting}>
              <FileArchive className="h-4 w-4" />
              {exporting ? "Gerando pacote…" : "Baixar pacote (.zip)"}
            </Button>
            <Button variant="outline" onClick={handleExportCsvOnly} disabled={drafts.length === 0}>
              <Download className="h-4 w-4" /> Baixar apenas o CSV
            </Button>
          </div>
        </Card>
      </Container>

      {previewingId && previewUrl && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Pré-visualização do vídeo"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4"
        >
          <button
            onClick={closePreview}
            aria-label="Fechar pré-visualização"
            className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white hover:bg-white/20"
          >
            <X className="h-6 w-6" />
          </button>
          <video src={previewUrl} controls autoPlay className="max-h-[80vh] rounded-xl" />
        </div>
      )}
    </>
  );
}
