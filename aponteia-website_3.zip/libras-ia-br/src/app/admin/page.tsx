import type { Metadata } from "next";
import {
  Users,
  Files,
  Cpu,
  AlertTriangle,
  Wallet,
  Hand,
  ShieldAlert,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, Badge } from "@/components/ui/Card";
import { ButtonLink } from "@/components/ui/Button";
import { SIGN_LIBRARY } from "@/lib/libras-data";

export const metadata: Metadata = {
  title: "Painel administrativo",
  description: "Métricas e gestão da plataforma AponteIA (acesso restrito).",
  robots: { index: false, follow: false },
};

const STATS = [
  { label: "Usuários ativos (30 dias)", value: "4.812", icon: Users },
  { label: "Arquivos processados", value: "12.309", icon: Files },
  { label: "Processamentos hoje", value: "742", icon: Cpu },
  { label: "Taxa de erro", value: "1,8%", icon: AlertTriangle },
];

const USAGE_BY_TOOL = [
  { tool: "Fala → Texto", value: 38 },
  { tool: "Texto → Voz", value: 22 },
  { tool: "Legendas", value: 18 },
  { tool: "OCR", value: 12 },
  { tool: "Assistente IA", value: 7 },
  { tool: "Libras (experimental)", value: 3 },
];

const RECENT_USERS = [
  { name: "Marina Souza", email: "marina@exemplo.com", status: "Ativo", since: "12/06/2026" },
  { name: "Pedro Lima", email: "pedro@exemplo.com", status: "Ativo", since: "10/06/2026" },
  { name: "Escola Vale Verde", email: "contato@valeverde.edu.br", status: "Institucional", since: "02/06/2026" },
  { name: "Juliana Ferreira", email: "ju.ferreira@exemplo.com", status: "Bloqueado", since: "28/05/2026" },
];

const RECENT_ERRORS = [
  { context: "Legendas", message: "Tempo limite ao processar vídeo de 45 min.", when: "há 2h" },
  { context: "OCR", message: "Falha ao carregar dados de idioma.", when: "há 5h" },
  { context: "Assistente IA", message: "Limite de requisições atingido para o usuário.", when: "há 1 dia" },
];

export default function AdminPage() {
  const maxUsage = Math.max(...USAGE_BY_TOOL.map((u) => u.value));

  return (
    <>
      <PageHeader
        eyebrow="Acesso restrito"
        title="Painel administrativo"
        description="Visão geral de usuários, processamentos, erros e uso de IA. Conteúdos privados dos usuários não ficam visíveis aqui sem autorização e controles apropriados."
      />
      <Container className="py-10 sm:py-14">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((s) => (
            <Card key={s.label}>
              <s.icon className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" />
              <p className="mt-3 text-2xl font-bold">{s.value}</p>
              <p className="text-sm text-[var(--color-text-muted)]">{s.label}</p>
            </Card>
          ))}
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.1fr_1fr]">
          <Card>
            <h2 className="font-semibold">Uso por ferramenta (últimos 30 dias)</h2>
            <ul className="mt-4 flex flex-col gap-3">
              {USAGE_BY_TOOL.map((u) => (
                <li key={u.tool}>
                  <div className="mb-1 flex items-center justify-between text-sm">
                    <span>{u.tool}</span>
                    <span className="font-medium text-[var(--color-text-muted)]">{u.value}%</span>
                  </div>
                  <div className="h-2.5 w-full overflow-hidden rounded-full bg-[var(--color-bg-subtle)]">
                    <div
                      className="h-full rounded-full bg-[var(--color-primary)]"
                      style={{ width: `${(u.value / maxUsage) * 100}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          </Card>

          <Card>
            <h2 className="flex items-center gap-2 font-semibold">
              <Wallet className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" />
              Custo estimado de IA (mês atual)
            </h2>
            <p className="mt-3 text-3xl font-bold">R$ 0,00</p>
            <p className="mt-1 text-sm text-[var(--color-text-muted)]">
              Nenhum provedor de IA pago está conectado nesta demonstração. Assim que uma
              chave de API for configurada, os custos reais aparecerão aqui por
              ferramenta.
            </p>
          </Card>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <Card>
            <h2 className="font-semibold">Usuários recentes</h2>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-[var(--color-border)] text-[var(--color-text-muted)]">
                    <th className="py-2 pr-4 font-medium">Nome</th>
                    <th className="py-2 pr-4 font-medium">E-mail</th>
                    <th className="py-2 pr-4 font-medium">Status</th>
                    <th className="py-2 font-medium">Desde</th>
                  </tr>
                </thead>
                <tbody>
                  {RECENT_USERS.map((u) => (
                    <tr key={u.email} className="border-b border-[var(--color-border)] last:border-0">
                      <td className="py-2.5 pr-4 font-medium">{u.name}</td>
                      <td className="py-2.5 pr-4 text-[var(--color-text-muted)]">{u.email}</td>
                      <td className="py-2.5 pr-4">
                        <Badge
                          tone={
                            u.status === "Bloqueado"
                              ? "warning"
                              : u.status === "Institucional"
                              ? "primary"
                              : "success"
                          }
                        >
                          {u.status}
                        </Badge>
                      </td>
                      <td className="py-2.5 text-[var(--color-text-muted)]">{u.since}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <Card>
            <h2 className="flex items-center gap-2 font-semibold">
              <AlertTriangle className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" />
              Erros recentes
            </h2>
            <ul className="mt-4 flex flex-col gap-3">
              {RECENT_ERRORS.map((e, i) => (
                <li key={i} className="rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-3">
                  <p className="text-xs font-semibold uppercase text-[var(--color-primary)]">{e.context}</p>
                  <p className="mt-1 text-sm">{e.message}</p>
                  <p className="mt-1 text-xs text-[var(--color-text-muted)]">{e.when}</p>
                </li>
              ))}
            </ul>
          </Card>
        </div>

        <Card className="mt-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h2 className="flex items-center gap-2 font-semibold">
                <Hand className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" />
                Biblioteca de Libras
              </h2>
              <p className="mt-2 text-sm text-[var(--color-text-muted)]">
                Gerencie sinais, categorias, vídeos e revisões da comunidade.{" "}
                <span className="font-medium text-[var(--color-text)]">
                  {SIGN_LIBRARY.length} sinais
                </span>{" "}
                publicados no dicionário,{" "}
                <span className="font-medium text-[var(--color-text)]">
                  {SIGN_LIBRARY.filter((s) => s.status === "revisado").length}
                </span>{" "}
                já revisados e{" "}
                <span className="font-medium text-[var(--color-text)]">
                  {SIGN_LIBRARY.filter((s) => !s.videoUrl).length}
                </span>{" "}
                com vídeo pendente.
              </p>
            </div>
            <ButtonLink href="/admin/libras" size="sm" variant="outline">
              Gerenciar sinais
            </ButtonLink>
          </div>
        </Card>

        <Card className="mt-6 flex items-start gap-3 border-amber-500/40 bg-amber-500/10">
          <ShieldAlert className="h-6 w-6 shrink-0 text-amber-600 dark:text-amber-400" aria-hidden="true" />
          <p className="text-sm text-amber-900 dark:text-amber-300">
            Por política da plataforma, administradores não têm acesso ao conteúdo privado
            de transcrições, conversas ou arquivos dos usuários sem autorização explícita e
            registro de auditoria.
          </p>
        </Card>
      </Container>
    </>
  );
}
