"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { User, Shield, Globe, Settings2, Check, Trash2 } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Field } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";
import { RequireAuthNotice } from "@/components/RequireAuthNotice";
import { useAuth } from "@/lib/auth";
import { useAccessibility } from "@/lib/accessibility";

export function PerfilClient() {
  const { user, loading, updateProfile, logout } = useAuth();
  const { settings } = useAccessibility();
  const router = useRouter();
  const [name, setName] = useState(user?.name ?? "");
  const [saved, setSaved] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  if (loading) return null;
  if (!user) return <RequireAuthNotice title="Meu perfil" />;

  function handleSave() {
    updateProfile({ name });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2000);
  }

  function handleDelete() {
    logout();
    router.push("/");
  }

  return (
    <>
      <PageHeader eyebrow="Sua conta" title="Meu perfil" description="Gerencie suas informações e preferências." />
      <Container className="py-10 sm:py-14">
        <div className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
          <div className="flex flex-col items-center gap-4 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-8 text-center lg:sticky lg:top-24 lg:self-start">
            <span className="flex h-24 w-24 items-center justify-center rounded-full bg-[var(--color-primary)] text-3xl font-bold text-[var(--color-primary-contrast)]">
              {user.name.slice(0, 1).toUpperCase()}
            </span>
            <div>
              <p className="text-lg font-semibold">{user.name}</p>
              <p className="text-sm text-[var(--color-text-muted)]">{user.email}</p>
            </div>
            <Button variant="outline" size="sm" fullWidth disabled>
              Alterar foto (em breve)
            </Button>
          </div>

          <div className="flex flex-col gap-6">
            <Card>
              <h2 className="flex items-center gap-2 font-semibold">
                <User className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" /> Informações
              </h2>
              <div className="mt-4 flex flex-col gap-4">
                <Field id="perfil-nome" label="Nome" value={name} onChange={(e) => setName(e.target.value)} />
                <Field id="perfil-email" label="E-mail" value={user.email} disabled />
                <div>
                  <Button size="sm" onClick={handleSave}>
                    {saved ? <Check className="h-4 w-4" /> : null}
                    {saved ? "Salvo" : "Salvar alterações"}
                  </Button>
                </div>
              </div>
            </Card>

            <Card>
              <h2 className="flex items-center gap-2 font-semibold">
                <Globe className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" /> Idioma
              </h2>
              <p className="mt-2 text-sm text-[var(--color-text-muted)]">
                No momento, o AponteIA está disponível em português brasileiro.
              </p>
            </Card>

            <Card>
              <div className="flex items-center justify-between">
                <h2 className="flex items-center gap-2 font-semibold">
                  <Settings2 className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" /> Acessibilidade
                </h2>
                <Link href="/acessibilidade" className="text-sm font-medium text-[var(--color-primary)] hover:underline">
                  Editar
                </Link>
              </div>
              <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
                <div>
                  <dt className="text-[var(--color-text-muted)]">Texto</dt>
                  <dd className="font-medium capitalize">{settings.fontSize.replace("-", " ")}</dd>
                </div>
                <div>
                  <dt className="text-[var(--color-text-muted)]">Contraste</dt>
                  <dd className="font-medium capitalize">{settings.contrast}</dd>
                </div>
                <div>
                  <dt className="text-[var(--color-text-muted)]">Tema</dt>
                  <dd className="font-medium capitalize">{settings.theme}</dd>
                </div>
              </dl>
            </Card>

            <Card>
              <h2 className="flex items-center gap-2 font-semibold">
                <Shield className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" /> Segurança
              </h2>
              <div className="mt-4 flex flex-col gap-3">
                <Button variant="outline" size="sm" fullWidth disabled>
                  Alterar senha (em breve)
                </Button>
                <Button variant="ghost" size="sm" fullWidth onClick={logout}>
                  Sair de todos os dispositivos
                </Button>
              </div>
              <div className="mt-6 border-t border-[var(--color-border)] pt-4">
                {!confirmDelete ? (
                  <Button variant="danger" size="sm" onClick={() => setConfirmDelete(true)}>
                    <Trash2 className="h-4 w-4" /> Excluir conta e dados
                  </Button>
                ) : (
                  <div className="rounded-xl border border-red-500/40 bg-red-500/10 p-4">
                    <p className="text-sm font-medium text-red-700 dark:text-red-400">
                      Tem certeza? Essa ação remove sua conta e histórico salvos neste
                      navegador e não pode ser desfeita.
                    </p>
                    <div className="mt-3 flex gap-2">
                      <Button variant="danger" size="sm" onClick={handleDelete}>
                        Sim, excluir
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => setConfirmDelete(false)}>
                        Cancelar
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>
        </div>
      </Container>
    </>
  );
}
