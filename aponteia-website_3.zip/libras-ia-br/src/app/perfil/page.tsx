import type { Metadata } from "next";
import { PerfilClient } from "./PerfilClient";

export const metadata: Metadata = {
  title: "Meu perfil",
  description: "Gerencie suas informações, preferências, acessibilidade e segurança.",
};

export default function Page() {
  return <PerfilClient />;
}
