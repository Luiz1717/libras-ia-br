import type { Metadata } from "next";
import { DashboardClient } from "./DashboardClient";

export const metadata: Metadata = {
  title: "Painel",
  description: "Seu painel AponteIA: acesso rápido às ferramentas e histórico recente.",
};

export default function Page() {
  return <DashboardClient />;
}
