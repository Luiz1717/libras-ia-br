"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Mic,
  Captions,
  Volume2,
  ScanText,
  Hand,
  Bot,
  ArrowRight,
  Clock,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { Card } from "@/components/ui/Card";
import { RequireAuthNotice } from "@/components/RequireAuthNotice";
import { useAuth } from "@/lib/auth";
import { getHistory, historyTypeLabel, type HistoryItem } from "@/lib/history";

const QUICK_ACCESS = [
  { href: "/voz-para-texto", icon: Mic, label: "Voz → Texto" },
  { href: "/legendas", icon: Captions, label: "Legendas" },
  { href: "/texto-para-voz", icon: Volume2, label: "Texto → Voz" },
  { href: "/ocr", icon: ScanText, label: "OCR" },
  { href: "/libras", icon: Hand, label: "Libras" },
  { href: "/ia", icon: Bot, label: "IA" },
];

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function DashboardClient() {
  const { user, loading } = useAuth();
  const [items, setItems] = useState<HistoryItem[]>([]);

  useEffect(() => {
    // Lê o histórico salvo no armazenamento local, disponível só no cliente.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (user) setItems(getHistory().slice(0, 5));
  }, [user]);

  if (loading) return null;
  if (!user) return <RequireAuthNotice title="Painel" />;

  return (
    <Container className="py-10 sm:py-14">
      <h1 className="text-3xl font-bold">Olá, {user.name.split(" ")[0]}!</h1>
      <p className="mt-1 text-[var(--color-text-muted)]">
        Aqui está o que está acontecendo na sua conta.
      </p>

      <h2 className="mt-10 text-lg font-semibold">Acesso rápido</h2>
      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {QUICK_ACCESS.map((q) => (
          <Link
            key={q.href}
            href={q.href}
            className="flex flex-col items-center gap-2 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-4 text-center text-sm font-medium hover:border-[var(--color-primary)] hover:text-[var(--color-primary)]"
          >
            <q.icon className="h-6 w-6" aria-hidden="true" />
            {q.label}
          </Link>
        ))}
      </div>

      <div className="mt-10 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Histórico recente</h2>
        <Link
          href="/historico"
          className="flex items-center gap-1 text-sm font-medium text-[var(--color-primary)] hover:underline"
        >
          Ver tudo <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>
      </div>

      <div className="mt-4 flex flex-col gap-3">
        {items.length === 0 && (
          <Card className="text-center text-[var(--color-text-muted)]">
            Você ainda não tem trabalhos recentes.
          </Card>
        )}
        {items.map((item) => (
          <Card key={item.id} className="flex items-center gap-4 py-4">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[var(--color-primary)]/10 text-[var(--color-primary)]">
              <Clock className="h-5 w-5" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{item.title}</p>
              <p className="truncate text-sm text-[var(--color-text-muted)]">
                {item.preview}
              </p>
            </div>
            <div className="hidden shrink-0 text-right text-xs text-[var(--color-text-muted)] sm:block">
              <p>{historyTypeLabel(item.type)}</p>
              <p>{formatDate(item.createdAt)}</p>
            </div>
          </Card>
        ))}
      </div>
    </Container>
  );
}
