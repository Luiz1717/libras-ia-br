import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";

export const metadata: Metadata = {
  title: "Privacidade",
  description: "Como o AponteIA trata seus dados, em conformidade com a LGPD.",
};

const SECTIONS = [
  {
    title: "Quais dados são coletados",
    content:
      "Coletamos apenas o necessário para o funcionamento das ferramentas: dados de cadastro (nome, e-mail), preferências de acessibilidade, e o conteúdo que você opta por enviar para processamento (texto, imagens, áudio ou vídeo). Não coletamos dados sensíveis sem necessidade direta da funcionalidade solicitada.",
  },
  {
    title: "Como os dados são utilizados",
    content:
      "Os dados enviados são usados exclusivamente para gerar o resultado solicitado por você — como uma transcrição, um resumo ou uma legenda — e, se você escolher salvar, para manter seu histórico pessoal disponível para consulta futura.",
  },
  {
    title: "Onde são armazenados",
    content:
      "Nesta versão de demonstração, os dados de conta e histórico ficam salvos apenas no seu próprio navegador (armazenamento local), e não são enviados a nenhum servidor externo. Em uma versão de produção, os dados seriam armazenados em infraestrutura segura, com criptografia em trânsito e em repouso.",
  },
  {
    title: "Por quanto tempo",
    content:
      "Evitamos guardar áudio e vídeo além do necessário para gerar o resultado solicitado. Textos e resultados salvos no histórico ficam disponíveis até que você decida excluí-los.",
  },
  {
    title: "Como excluir seus dados",
    content:
      "Você pode excluir itens individuais do seu histórico a qualquer momento na página Histórico, ou remover sua conta e todos os dados associados na página Meu Perfil.",
  },
  {
    title: "Como solicitar exclusão completa",
    content:
      "Além da exclusão pelo próprio painel, você pode solicitar a exclusão completa dos seus dados pelo formulário em Contribuição, informando o e-mail da sua conta.",
  },
];

export default function PrivacidadePage() {
  return (
    <>
      <PageHeader
        eyebrow="Seus dados, suas regras"
        title="Privacidade"
        description="Explicamos de forma clara o que fazemos com seus dados e como você mantém o controle sobre eles."
      />
      <Container className="py-10 sm:py-14">
        <Card className="mb-8 border-[var(--color-primary)]/30 bg-[var(--color-primary)]/5">
          <p className="leading-relaxed">
            Estamos comprometidos com práticas alinhadas à Lei Geral de Proteção de Dados
            (LGPD). Você tem controle sobre seus arquivos e pode consultar, corrigir ou
            excluir seus dados a qualquer momento.
          </p>
        </Card>
        <div className="flex flex-col gap-6">
          {SECTIONS.map((s) => (
            <Card key={s.title}>
              <h2 className="text-lg font-semibold">{s.title}</h2>
              <p className="mt-2 leading-relaxed text-[var(--color-text-muted)]">{s.content}</p>
            </Card>
          ))}
        </div>
      </Container>
    </>
  );
}
