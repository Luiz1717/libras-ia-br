import type { Metadata } from "next";
import { AcessibilidadeClient } from "./AcessibilidadeClient";

export const metadata: Metadata = {
  title: "Acessibilidade",
  description:
    "Configure tamanho do texto, contraste, tema, animações e densidade da interface do AponteIA.",
};

export default function Page() {
  return <AcessibilidadeClient />;
}
