"use client";

import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import {
  useAccessibility,
  type FontSize,
  type Contrast,
  type ThemeMode,
  type MotionMode,
  type Density,
} from "@/lib/accessibility";
import { Button } from "@/components/ui/Button";
import { Check, Type, Contrast as ContrastIcon, Sun, Waves, LayoutGrid } from "lucide-react";
import clsx from "clsx";

interface OptionDef<T extends string> {
  value: T;
  label: string;
  description: string;
}

function OptionGroup<T extends string>({
  legend,
  icon: Icon,
  options,
  value,
  onChange,
}: {
  legend: string;
  icon: React.ElementType;
  options: OptionDef<T>[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <Card>
      <fieldset>
        <legend className="flex items-center gap-2 text-lg font-semibold">
          <Icon className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" />
          {legend}
        </legend>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {options.map((opt) => {
            const active = opt.value === value;
            return (
              <label
                key={opt.value}
                className={clsx(
                  "flex cursor-pointer items-start gap-3 rounded-xl border-2 p-4 transition-colors",
                  active
                    ? "border-[var(--color-primary)] bg-[var(--color-primary)]/5"
                    : "border-[var(--color-border)] hover:border-[var(--color-primary)]/50"
                )}
              >
                <input
                  type="radio"
                  name={legend}
                  className="sr-only"
                  checked={active}
                  onChange={() => onChange(opt.value)}
                />
                <span
                  className={clsx(
                    "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2",
                    active
                      ? "border-[var(--color-primary)] bg-[var(--color-primary)] text-[var(--color-primary-contrast)]"
                      : "border-[var(--color-border)]"
                  )}
                  aria-hidden="true"
                >
                  {active && <Check className="h-3 w-3" />}
                </span>
                <span>
                  <span className="block font-medium">{opt.label}</span>
                  <span className="block text-sm text-[var(--color-text-muted)]">
                    {opt.description}
                  </span>
                </span>
              </label>
            );
          })}
        </div>
      </fieldset>
    </Card>
  );
}

const FONT_OPTIONS: OptionDef<FontSize>[] = [
  { value: "pequeno", label: "Pequeno", description: "Texto reduzido (90%)" },
  { value: "normal", label: "Normal", description: "Tamanho padrão (100%)" },
  { value: "grande", label: "Grande", description: "Texto ampliado (115%)" },
  { value: "muito-grande", label: "Muito grande", description: "Texto bem ampliado (135%)" },
];

const CONTRAST_OPTIONS: OptionDef<Contrast>[] = [
  { value: "normal", label: "Normal", description: "Paleta padrão com contraste AA" },
  { value: "alto", label: "Alto contraste", description: "Preto e branco com cores fortes" },
];

const THEME_OPTIONS: OptionDef<ThemeMode>[] = [
  { value: "claro", label: "Claro", description: "Fundo claro em qualquer horário" },
  { value: "escuro", label: "Escuro", description: "Fundo escuro em qualquer horário" },
  { value: "sistema", label: "Sistema", description: "Segue a configuração do dispositivo" },
];

const MOTION_OPTIONS: OptionDef<MotionMode>[] = [
  { value: "ativadas", label: "Ativadas", description: "Transições e animações completas" },
  { value: "reduzidas", label: "Reduzidas", description: "Quase sem animações na interface" },
];

const DENSITY_OPTIONS: OptionDef<Density>[] = [
  { value: "confortavel", label: "Confortável", description: "Mais espaço entre os elementos" },
  { value: "compacta", label: "Compacta", description: "Mais conteúdo visível por tela" },
];

export function AcessibilidadeClient() {
  const {
    settings,
    setFontSize,
    setContrast,
    setTheme,
    setMotion,
    setDensity,
    resetSettings,
  } = useAccessibility();

  return (
    <>
      <PageHeader
        eyebrow="Central de acessibilidade"
        title="Configurações de acessibilidade"
        description="Ajuste a interface do jeito que funciona melhor para você. As mudanças são aplicadas imediatamente e ficam salvas neste navegador."
      />
      <Container className="py-10 sm:py-14">
        <div className="grid gap-6">
          <OptionGroup
            legend="Tamanho do texto"
            icon={Type}
            options={FONT_OPTIONS}
            value={settings.fontSize}
            onChange={setFontSize}
          />
          <OptionGroup
            legend="Contraste"
            icon={ContrastIcon}
            options={CONTRAST_OPTIONS}
            value={settings.contrast}
            onChange={setContrast}
          />
          <OptionGroup
            legend="Tema"
            icon={Sun}
            options={THEME_OPTIONS}
            value={settings.theme}
            onChange={setTheme}
          />
          <OptionGroup
            legend="Animações"
            icon={Waves}
            options={MOTION_OPTIONS}
            value={settings.motion}
            onChange={setMotion}
          />
          <OptionGroup
            legend="Interface"
            icon={LayoutGrid}
            options={DENSITY_OPTIONS}
            value={settings.density}
            onChange={setDensity}
          />
        </div>

        <div className="mt-8 flex flex-col items-start gap-3 rounded-2xl border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-[var(--color-text-muted)]">
            Toda informação importante nesta plataforma tem apoio visual — nunca dependemos
            apenas de som ou alertas sonoros.
          </p>
          <Button variant="outline" size="sm" onClick={resetSettings}>
            Restaurar padrões
          </Button>
        </div>
      </Container>
    </>
  );
}
