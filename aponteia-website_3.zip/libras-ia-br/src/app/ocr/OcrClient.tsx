"use client";

import { useRef, useState } from "react";
import { UploadCloud, Camera, Copy, Volume2, Sparkles, X, Check } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { StatusBadge, type ProcessState } from "@/components/ui/StatusBadge";
import { mockSummarize, mockExplainSimple } from "@/lib/ai";
import { addHistoryItem } from "@/lib/history";

export function OcrClient() {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [status, setStatus] = useState<ProcessState>("idle");
  const [progress, setProgress] = useState(0);
  const [text, setText] = useState("");
  const [aiOutput, setAiOutput] = useState<{ kind: string; content: string } | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  async function runOcr(source: File | Blob) {
    setStatus("processando");
    setProgress(0);
    setAiOutput(null);
    try {
      const Tesseract = await import("tesseract.js");
      const { data } = await Tesseract.recognize(source, "por", {
        logger: (m) => {
          if (m.status === "recognizing text" && typeof m.progress === "number") {
            setProgress(Math.round(m.progress * 100));
          }
        },
      });
      const recognized = data.text.trim();
      setText(recognized || "Não foi possível identificar texto nesta imagem.");
      setStatus("concluido");
      if (recognized) {
        addHistoryItem({
          type: "ocr",
          title: recognized.slice(0, 60) || "Leitura de imagem",
          preview: recognized.slice(0, 140),
        });
      }
    } catch {
      setStatus("erro");
    }
  }

  function handleFile(file: File) {
    setImageUrl(URL.createObjectURL(file));
    runOcr(file);
  }

  function onInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }

  function onDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  }

  async function openCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      streamRef.current = stream;
      setCameraOpen(true);
      window.setTimeout(() => {
        if (videoRef.current) videoRef.current.srcObject = stream;
      }, 50);
    } catch {
      setStatus("erro");
    }
  }

  function closeCamera() {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraOpen(false);
  }

  function capturePhoto() {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx?.drawImage(video, 0, 0);
    canvas.toBlob((blob) => {
      if (blob) {
        setImageUrl(URL.createObjectURL(blob));
        runOcr(blob);
      }
    }, "image/png");
    closeCamera();
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      // indisponível
    }
  }

  function handleListen() {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "pt-BR";
    window.speechSynthesis.speak(utterance);
  }

  async function handleSummarize() {
    setAiLoading(true);
    setAiOutput(null);
    const result = await mockSummarize(text);
    setAiOutput({ kind: "Resumo", content: result });
    setAiLoading(false);
  }

  async function handleExplain() {
    setAiLoading(true);
    setAiOutput(null);
    const result = await mockExplainSimple(text);
    setAiOutput({ kind: "Explicação", content: result });
    setAiLoading(false);
  }

  return (
    <>
      <PageHeader
        eyebrow="Ferramenta"
        title="Imagem → Texto (OCR)"
        description="Envie, arraste ou fotografe uma imagem para reconhecer o texto automaticamente."
      />
      <Container className="py-10 sm:py-14">
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            {!imageUrl ? (
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                className={`flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-10 text-center transition-colors ${
                  dragOver
                    ? "border-[var(--color-primary)] bg-[var(--color-primary)]/5"
                    : "border-[var(--color-border)]"
                }`}
              >
                <UploadCloud className="h-10 w-10 text-[var(--color-text-muted)]" aria-hidden="true" />
                <p className="font-medium">Arraste uma imagem aqui</p>
                <p className="text-sm text-[var(--color-text-muted)]">ou</p>
                <div className="flex flex-wrap justify-center gap-3">
                  <Button size="sm" onClick={() => fileInputRef.current?.click()}>
                    Selecionar imagem
                  </Button>
                  <Button size="sm" variant="outline" onClick={openCamera}>
                    <Camera className="h-4 w-4" /> Abrir câmera
                  </Button>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={onInputChange}
                />
              </div>
            ) : (
              <div>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={imageUrl}
                  alt="Imagem enviada para reconhecimento de texto"
                  className="max-h-96 w-full rounded-xl object-contain"
                />
                <div className="mt-4 flex items-center justify-between">
                  <StatusBadge
                    state={status}
                    label={status === "processando" ? `Processando… ${progress}%` : undefined}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setImageUrl(null);
                      setText("");
                      setStatus("idle");
                      setAiOutput(null);
                    }}
                  >
                    Nova imagem
                  </Button>
                </div>
              </div>
            )}
          </Card>

          <Card>
            <h2 className="font-semibold">Texto identificado</h2>
            <label htmlFor="ocr-text" className="sr-only">
              Texto reconhecido (editável)
            </label>
            <textarea
              id="ocr-text"
              rows={10}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="O texto reconhecido vai aparecer aqui e pode ser editado."
              className="mt-3 w-full resize-y rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-4 leading-relaxed outline-none focus:border-[var(--color-primary)]"
            />
            <div className="mt-4 flex flex-wrap gap-2">
              <Button size="sm" variant="outline" onClick={handleCopy} disabled={!text}>
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copiado" : "Copiar"}
              </Button>
              <Button size="sm" variant="outline" onClick={handleListen} disabled={!text}>
                <Volume2 className="h-4 w-4" /> Ouvir
              </Button>
              <Button size="sm" variant="outline" onClick={handleSummarize} disabled={!text || aiLoading}>
                <Sparkles className="h-4 w-4" /> Resumir
              </Button>
              <Button size="sm" variant="outline" onClick={handleExplain} disabled={!text || aiLoading}>
                <Sparkles className="h-4 w-4" /> Explicar com IA
              </Button>
            </div>
            {aiLoading && (
              <p role="status" className="mt-3 text-sm text-[var(--color-text-muted)]">
                Processando com IA…
              </p>
            )}
            {aiOutput && (
              <div className="mt-3 rounded-xl border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-4">
                <p className="text-xs font-semibold uppercase text-[var(--color-primary)]">
                  {aiOutput.kind}
                </p>
                <p className="mt-1 text-sm leading-relaxed">{aiOutput.content}</p>
              </div>
            )}
          </Card>
        </div>
      </Container>

      {cameraOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Capturar foto"
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 p-4"
        >
          <button
            onClick={closeCamera}
            aria-label="Fechar câmera"
            className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white hover:bg-white/20"
          >
            <X className="h-6 w-6" />
          </button>
          <video ref={videoRef} autoPlay playsInline muted className="max-h-[70vh] rounded-xl" />
          <button
            onClick={capturePhoto}
            className="mt-6 flex h-16 w-16 items-center justify-center rounded-full border-4 border-white bg-white/20"
            aria-label="Capturar foto"
          >
            <span className="h-12 w-12 rounded-full bg-white" />
          </button>
        </div>
      )}
      <canvas ref={canvasRef} className="hidden" />
    </>
  );
}
