import type { Metadata } from "next";
import { OcrClient } from "./OcrClient";

export const metadata: Metadata = {
  title: "Imagem → Texto (OCR)",
  description:
    "Envie, arraste ou fotografe uma imagem e reconheça o texto automaticamente com OCR.",
};

export default function Page() {
  return <OcrClient />;
}
