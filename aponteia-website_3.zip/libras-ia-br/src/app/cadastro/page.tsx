import type { Metadata } from "next";
import { CadastroClient } from "./CadastroClient";

export const metadata: Metadata = {
  title: "Criar conta",
  description: "Crie sua conta gratuita no AponteIA.",
};

export default function Page() {
  return <CadastroClient />;
}
