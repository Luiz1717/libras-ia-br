"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AuthCard, ProviderButtons } from "@/components/AuthCard";
import { Field } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";
import { useAuth } from "@/lib/auth";

interface Errors {
  name?: string;
  email?: string;
  password?: string;
  confirm?: string;
}

export function CadastroClient() {
  const { register, loginWithProvider } = useAuth();
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const nextErrors: Errors = {};
    if (name.trim().length < 2) nextErrors.name = "Digite seu nome completo.";
    if (!/^\S+@\S+\.\S+$/.test(email)) nextErrors.email = "Digite um e-mail válido.";
    if (password.length < 6) nextErrors.password = "A senha deve ter pelo menos 6 caracteres.";
    if (confirm !== password) nextErrors.confirm = "As senhas não coincidem.";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setLoading(true);
    try {
      await register(name, email, password);
      router.push("/dashboard");
    } finally {
      setLoading(false);
    }
  }

  async function handleProvider(provider: "google" | "apple") {
    setLoading(true);
    try {
      await loginWithProvider(provider);
      router.push("/dashboard");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthCard
      title="Criar conta"
      description="Leva menos de um minuto. É gratuito."
      footer={
        <>
          Já tem uma conta?{" "}
          <Link href="/entrar" className="font-semibold text-[var(--color-primary)] hover:underline">
            Entrar
          </Link>
        </>
      }
    >
      <form className="flex flex-col gap-4" onSubmit={handleSubmit} noValidate>
        <Field
          id="name"
          label="Nome"
          autoComplete="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          error={errors.name}
          placeholder="Seu nome completo"
        />
        <Field
          id="email"
          label="E-mail"
          type="email"
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={errors.email}
          placeholder="voce@exemplo.com"
        />
        <Field
          id="password"
          label="Senha"
          type="password"
          autoComplete="new-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={errors.password}
          hint="Mínimo de 6 caracteres."
        />
        <Field
          id="confirm"
          label="Confirmar senha"
          type="password"
          autoComplete="new-password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          error={errors.confirm}
        />
        <Button type="submit" fullWidth disabled={loading}>
          {loading ? "Criando conta…" : "Criar conta"}
        </Button>
      </form>

      <div className="my-6 flex items-center gap-3 text-xs text-[var(--color-text-muted)]">
        <span className="h-px flex-1 bg-[var(--color-border)]" />
        ou continue com
        <span className="h-px flex-1 bg-[var(--color-border)]" />
      </div>
      <ProviderButtons onSelect={handleProvider} />

      <p className="mt-6 text-xs text-[var(--color-text-muted)]">
        Ao criar uma conta, você concorda com o tratamento de dados descrito na nossa{" "}
        <Link href="/privacidade" className="underline">
          página de Privacidade
        </Link>
        .
      </p>
    </AuthCard>
  );
}
