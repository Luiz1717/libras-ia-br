import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AccessibilityProvider } from "@/lib/accessibility";
import { AuthProvider } from "@/lib/auth";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ServiceWorkerRegister } from "@/components/ServiceWorkerRegister";
import { InstallPwaBanner } from "@/components/InstallPwaBanner";

export const metadata: Metadata = {
  metadataBase: new URL("https://aponteia.exemplo.com.br"),
  title: {
    default: "AponteIA — Inteligência Artificial para acessibilidade e Libras",
    template: "%s · AponteIA",
  },
  description:
    "Plataforma brasileira de tecnologia assistiva com IA: Libras, legendas, voz, texto e OCR para ampliar a autonomia da comunidade surda.",
  applicationName: "AponteIA",
  keywords: [
    "Libras",
    "acessibilidade",
    "IA para surdos",
    "legendas automáticas",
    "fala para texto",
    "texto para voz",
    "tecnologia assistiva",
    "comunidade surda brasileira",
  ],
  manifest: "/manifest.webmanifest",
  openGraph: {
    type: "website",
    locale: "pt_BR",
    siteName: "AponteIA",
    title: "AponteIA — Inteligência Artificial para acessibilidade e Libras",
    description:
      "Tecnologia que aproxima pessoas. IA que amplia a acessibilidade da comunidade surda brasileira.",
  },
  twitter: {
    card: "summary_large_image",
    title: "AponteIA — IA para acessibilidade e Libras",
    description:
      "Plataforma brasileira de tecnologia assistiva: Libras, legendas, voz, texto e OCR.",
  },
  icons: {
    icon: [
      { url: "/icons/icon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
    ],
    apple: "/icons/icon-180.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#1857c9",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="pt-BR" className="h-full antialiased" suppressHydrationWarning>
      <body className="min-h-full flex flex-col bg-[var(--color-bg)] text-[var(--color-text)]">
        <AccessibilityProvider>
          <AuthProvider>
            <Header />
            <main id="conteudo-principal" className="flex-1">
              {children}
            </main>
            <Footer />
            <ServiceWorkerRegister />
            <InstallPwaBanner />
          </AuthProvider>
        </AccessibilityProvider>
      </body>
    </html>
  );
}
