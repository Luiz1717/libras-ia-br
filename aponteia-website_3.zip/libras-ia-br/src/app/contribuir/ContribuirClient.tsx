"use client";

import { FormEvent, useState } from "react";
import { CheckCircle2, MessageSquareWarning, Hand, FlaskConical, BookOpenCheck } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Field } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";

type Kind = "sugestao" | "erro" | "sinal" | "teste" | "pesquisa";

const KIND_OPTIONS: { value: Kind; label: string; icon: React.ElementType }[] = [
  { value: "sugestao", label: "Enviar sugestão", icon: MessageSquareWarning },
  { value: "erro", label: "Relatar erro", icon: MessageSquareWarning },
  { value: "sinal", label: "Sugerir sinal", icon: Hand },
  { value: "teste", label: "Participar de testes", icon: FlaskConical },
  { value: "pesquisa", label: "Contribuir com pesquisas", icon: BookOpenCheck },
];

export function ContribuirClient() {
  const [kind, setKind] = useState<Kind>("sugestao");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSending(true);
    await new Promise((r) => setTimeout(r, 700));
    setSending(false);
    setSent(true);
  }

  if (sent) {
    return (
      <Container className="flex flex-col items-center gap-4 py-24 text-center">
        <CheckCircle2 className="h-14 w-14 text-emerald-500" aria-hidden="true" />
        <h1 className="text-2xl font-bold">Obrigado pela sua contribuição!</h1>
        <p className="max-w-md text-[var(--color-text-muted)]">
          Sua mensagem foi recebida (simulação). A equipe do AponteIA vai analisar e, se
          necessário, entrar em contato pelo e-mail informado.
        </p>
      </Container>
    );
  }

  return (
    <>
      <PageHeader
        eyebrow="Comunidade"
        title="Faça parte do projeto"
        description="O AponteIA é construído com a comunidade surda brasileira. Sua sugestão, correção ou disponibilidade para testes faz diferença."
      />
      <Container className="py-10 sm:py-14">
        <div className="grid gap-8 lg:grid-cols-[1fr_1.2fr]">
          <div className="flex flex-col gap-3">
            {KIND_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setKind(opt.value)}
                aria-pressed={kind === opt.value}
                className={`flex items-center gap-3 rounded-xl border-2 p-4 text-left transition-colors ${
                  kind === opt.value
                    ? "border-[var(--color-primary)] bg-[var(--color-primary)]/5"
                    : "border-[var(--color-border)]"
                }`}
              >
                <opt.icon className="h-5 w-5 text-[var(--color-primary)]" aria-hidden="true" />
                <span className="font-medium">{opt.label}</span>
              </button>
            ))}
          </div>

          <Card>
            <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
              <Field
                id="c-name"
                label="Nome"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
              <Field
                id="c-email"
                label="E-mail"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                hint="Usamos apenas para responder sua mensagem, se necessário."
              />
              <div className="flex flex-col gap-1.5">
                <label htmlFor="c-message" className="text-sm font-medium">
                  Mensagem
                </label>
                <textarea
                  id="c-message"
                  rows={6}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Conte com detalhes o que você gostaria de compartilhar…"
                  className="resize-y rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg)] px-4 py-2.5 outline-none focus:border-[var(--color-primary)]"
                />
              </div>
              <Button type="submit" disabled={sending}>
                {sending ? "Enviando…" : "Enviar"}
              </Button>
            </form>
          </Card>
        </div>
      </Container>
    </>
  );
}
