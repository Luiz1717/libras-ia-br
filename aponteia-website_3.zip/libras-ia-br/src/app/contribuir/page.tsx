import type { Metadata } from "next";
import { ContribuirClient } from "./ContribuirClient";

export const metadata: Metadata = {
  title: "Faça parte do projeto",
  description:
    "Envie sugestões, relate erros, sugira sinais de Libras e participe de testes com a comunidade AponteIA.",
};

export default function Page() {
  return <ContribuirClient />;
}
