"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AuthCard, ProviderButtons } from "@/components/AuthCard";
import { Field } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";
import { useAuth } from "@/lib/auth";

export function EntrarClient() {
  const { login, loginWithProvider } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [loading, setLoading] = useState(false);
  const [formError, setFormError] = useState("");

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const nextErrors: typeof errors = {};
    if (!/^\S+@\S+\.\S+$/.test(email)) nextErrors.email = "Digite um e-mail válido.";
    if (password.length < 6) nextErrors.password = "A senha deve ter pelo menos 6 caracteres.";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setLoading(true);
    setFormError("");
    try {
      await login(email, password);
      router.push("/dashboard");
    } catch {
      setFormError("Não foi possível entrar. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  async function handleProvider(provider: "google" | "apple") {
    setLoading(true);
    try {
      await loginWithProvider(provider);
      router.push("/dashboard");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthCard
      title="Entrar"
      description="Acesse sua conta para continuar de onde parou."
      footer={
        <>
          Ainda não tem conta?{" "}
          <Link href="/cadastro" className="font-semibold text-[var(--color-primary)] hover:underline">
            Criar conta
          </Link>
        </>
      }
    >
      <form className="flex flex-col gap-4" onSubmit={handleSubmit} noValidate>
        <Field
          id="email"
          label="E-mail"
          type="email"
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={errors.email}
          placeholder="voce@exemplo.com"
        />
        <Field
          id="password"
          label="Senha"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={errors.password}
        />
        {formError && (
          <p role="alert" className="text-sm font-medium text-red-600 dark:text-red-400">
            {formError}
          </p>
        )}
        <Button type="submit" fullWidth disabled={loading}>
          {loading ? "Entrando…" : "Entrar"}
        </Button>
      </form>

      <div className="my-6 flex items-center gap-3 text-xs text-[var(--color-text-muted)]">
        <span className="h-px flex-1 bg-[var(--color-border)]" />
        ou continue com
        <span className="h-px flex-1 bg-[var(--color-border)]" />
      </div>
      <ProviderButtons onSelect={handleProvider} />

      <p className="mt-6 text-xs text-[var(--color-text-muted)]">
        Este é um ambiente de demonstração: nenhuma senha real é verificada nem armazenada
        em servidor.
      </p>
    </AuthCard>
  );
}
