import type { Metadata } from "next";
import { EntrarClient } from "./EntrarClient";

export const metadata: Metadata = {
  title: "Entrar",
  description: "Acesse sua conta AponteIA para salvar histórico e preferências.",
};

export default function Page() {
  return <EntrarClient />;
}
