import type { Metadata } from "next";
import { LibrasClient } from "./LibrasClient";

export const metadata: Metadata = {
  title: "Libras",
  description:
    "Recursos de Libras: reconhecimento experimental por câmera, Português → Libras, dicionário de sinais, conteúdos para aprender e frases úteis por categoria.",
};

export default function Page() {
  return <LibrasClient />;
}
