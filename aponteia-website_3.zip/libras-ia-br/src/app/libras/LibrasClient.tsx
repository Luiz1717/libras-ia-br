"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Camera,
  CameraOff,
  Sparkles,
  Search,
  Volume2,
  Copy,
  Hand,
  Type,
  BookOpen,
  GraduationCap,
  MessageCircleHeart,
  Check,
  Clock,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader, ExperimentalNotice } from "@/components/ui/PageHeader";
import { Card, Badge } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import {
  SIGN_CATEGORIES,
  SIGN_LIBRARY,
  USEFUL_PHRASES,
  type SignEntry,
} from "@/lib/libras-data";

type Tab = "libras-texto" | "texto-libras" | "dicionario" | "aprender" | "frases";

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "libras-texto", label: "Libras → Texto", icon: Hand },
  { id: "texto-libras", label: "Português → Libras", icon: Type },
  { id: "dicionario", label: "Dicionário", icon: Search },
  { id: "aprender", label: "Aprender Libras", icon: GraduationCap },
  { id: "frases", label: "Frases úteis", icon: MessageCircleHeart },
];

const MOCK_RESULTS = [
  "Olá, tudo bem?",
  "Obrigado(a)",
  "Preciso de ajuda",
  "Bom dia",
  "Sim",
  "Não entendi",
];

function speak(text: string) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "pt-BR";
  window.speechSynthesis.speak(utterance);
}

function LibrasParaTexto() {
  const [cameraOn, setCameraOn] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<{ text: string; confidence: number } | null>(null);
  const [cameraError, setCameraError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  async function toggleCamera() {
    if (cameraOn) {
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      setCameraOn(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      streamRef.current = stream;
      setCameraOn(true);
      setCameraError(false);
      window.setTimeout(() => {
        if (videoRef.current) videoRef.current.srcObject = stream;
      }, 50);
    } catch {
      setCameraError(true);
    }
  }

  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  function analyze() {
    setAnalyzing(true);
    setResult(null);
    window.setTimeout(() => {
      const text = MOCK_RESULTS[Math.floor(Math.random() * MOCK_RESULTS.length)];
      const confidence = 58 + Math.floor(Math.random() * 35);
      setResult({ text, confidence });
      setAnalyzing(false);
    }, 1600);
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card className="flex flex-col items-center gap-4">
        <div className="flex aspect-video w-full items-center justify-center overflow-hidden rounded-xl bg-black">
          {cameraOn ? (
            <video ref={videoRef} autoPlay playsInline muted className="h-full w-full object-cover" />
          ) : (
            <div className="flex flex-col items-center gap-2 text-white/60">
              <Camera className="h-10 w-10" aria-hidden="true" />
              <p className="text-sm">A câmera está desligada</p>
            </div>
          )}
        </div>
        {cameraError && (
          <p className="text-sm text-red-600 dark:text-red-400">
            Não foi possível acessar a câmera. Verifique as permissões do navegador.
          </p>
        )}
        <div className="flex flex-wrap justify-center gap-3">
          <Button onClick={toggleCamera} variant={cameraOn ? "outline" : "primary"}>
            {cameraOn ? <CameraOff className="h-4 w-4" /> : <Camera className="h-4 w-4" />}
            {cameraOn ? "Desligar câmera" : "Ativar câmera"}
          </Button>
          <Button onClick={analyze} variant="secondary" disabled={!cameraOn || analyzing}>
            <Sparkles className="h-4 w-4" />
            {analyzing ? "Analisando…" : "Analisar sinal"}
          </Button>
        </div>
      </Card>

      <Card className="flex flex-col gap-4">
        <h2 className="font-semibold">Resultado</h2>
        {analyzing && (
          <p role="status" className="text-[var(--color-text-muted)]">
            Analisando movimento, mãos e expressão facial…
          </p>
        )}
        {!analyzing && !result && (
          <p className="text-[var(--color-text-muted)]">
            Ative a câmera, sinalize e toque em &ldquo;Analisar sinal&rdquo; para ver um resultado
            estimado.
          </p>
        )}
        {result && (
          <div className="rounded-xl border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-5">
            <p className="text-xs font-semibold uppercase text-[var(--color-primary)]">
              Resultado
            </p>
            <p className="mt-1 text-2xl font-semibold">&ldquo;{result.text}&rdquo;</p>
            <div className="mt-3 flex items-center gap-2">
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-[var(--color-border)]">
                <div
                  className="h-full rounded-full bg-[var(--color-primary)]"
                  style={{ width: `${result.confidence}%` }}
                />
              </div>
              <span className="text-sm font-medium text-[var(--color-text-muted)]">
                {result.confidence}%
              </span>
            </div>
            <p className="mt-2 text-xs text-[var(--color-text-muted)]">
              Confiança estimada — resultado estimado pela IA.
            </p>
          </div>
        )}
        <ExperimentalNotice>
          O reconhecimento de Libras ainda está em desenvolvimento e pode apresentar erros.
          Para contextos importantes (saúde, jurídico, emergências), utilize sempre um
          intérprete humano.
        </ExperimentalNotice>
      </Card>
    </div>
  );
}

function TextoParaLibras() {
  const [text, setText] = useState("");
  const [glosses, setGlosses] = useState<string[] | null>(null);

  function generate() {
    const words = text
      .trim()
      .replace(/[.,!?]/g, "")
      .split(/\s+/)
      .filter(Boolean);
    setGlosses(words.map((w) => w.toUpperCase()));
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <label htmlFor="pt-input" className="mb-2 block text-sm font-medium">
          Texto em português
        </label>
        <textarea
          id="pt-input"
          rows={6}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Bom dia, tudo bem?"
          className="w-full resize-y rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-4 outline-none focus:border-[var(--color-primary)]"
        />
        <Button className="mt-4" onClick={generate} disabled={!text.trim()}>
          <Sparkles className="h-4 w-4" /> Gerar representação em Libras
        </Button>
      </Card>
      <Card>
        <h2 className="font-semibold">Pré-visualização</h2>
        <div className="mt-3 flex aspect-video items-center justify-center rounded-xl border border-dashed border-[var(--color-border)] bg-[var(--color-bg-subtle)] text-center text-sm text-[var(--color-text-muted)]">
          Avatar / vídeo em Libras
          <br />
          (em desenvolvimento)
        </div>
        {glosses && (
          <div className="mt-4">
            <p className="text-xs font-semibold uppercase text-[var(--color-primary)]">
              Glosa aproximada
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              {glosses.map((g, i) => (
                <span
                  key={i}
                  className="rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-2.5 py-1 text-sm font-medium"
                >
                  {g}
                </span>
              ))}
            </div>
          </div>
        )}
        <ExperimentalNotice>
          Libras tem gramática e estrutura espacial próprias — não é uma tradução
          palavra por palavra do português. Esta pré-visualização é simplificada e
          educativa.
        </ExperimentalNotice>
      </Card>
    </div>
  );
}

const PAGE_SIZE = 12;

function SignVideo({ sign }: { sign: SignEntry }) {
  if (!sign.videoUrl) {
    return (
      <div className="flex aspect-video flex-col items-center justify-center gap-1.5 rounded-lg bg-[var(--color-bg-subtle)] text-[var(--color-text-muted)]">
        <Hand className="h-8 w-8" aria-hidden="true" />
        <span className="text-xs font-medium">Vídeo pendente</span>
      </div>
    );
  }
  return (
    <video
      controls
      preload="none"
      poster={sign.posterUrl}
      className="aspect-video w-full rounded-lg bg-black object-cover"
      aria-label={`Vídeo do sinal de ${sign.word} em Libras`}
    >
      <source src={sign.videoUrl} />
      Seu navegador não é compatível com reprodução de vídeo.
    </video>
  );
}

function Dicionario() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("Todas");
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);

  const filtered = useMemo(() => {
    return SIGN_LIBRARY.filter((s) => {
      const matchQuery =
        query.trim() === "" || s.word.toLowerCase().includes(query.toLowerCase());
      const matchCategory = category === "Todas" || s.category === category;
      return matchQuery && matchCategory;
    });
  }, [query, category]);

  const visible = filtered.slice(0, visibleCount);
  const revisados = SIGN_LIBRARY.filter((s) => s.status === "revisado").length;

  function handleQueryChange(value: string) {
    setQuery(value);
    setVisibleCount(PAGE_SIZE);
  }

  function handleCategoryChange(value: string) {
    setCategory(value);
    setVisibleCount(PAGE_SIZE);
  }

  return (
    <div>
      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[var(--color-text-muted)]" />
        <label htmlFor="dict-search" className="sr-only">
          Pesquisar sinal
        </label>
        <input
          id="dict-search"
          type="search"
          value={query}
          onChange={(e) => handleQueryChange(e.target.value)}
          placeholder="Pesquisar palavra, ex.: computador"
          className="w-full rounded-full border-2 border-[var(--color-border)] bg-[var(--color-surface)] py-2.5 pl-11 pr-4 outline-none focus:border-[var(--color-primary)]"
        />
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {["Todas", ...SIGN_CATEGORIES].map((c) => (
          <button
            key={c}
            onClick={() => handleCategoryChange(c)}
            aria-pressed={category === c}
            className={`rounded-full border px-3.5 py-1.5 text-sm font-medium ${
              category === c
                ? "border-[var(--color-primary)] bg-[var(--color-primary)]/10 text-[var(--color-primary)]"
                : "border-[var(--color-border)] text-[var(--color-text-muted)]"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <p className="mt-4 text-sm text-[var(--color-text-muted)]">
        {filtered.length} sinal(is) encontrado(s) de {SIGN_LIBRARY.length} no total — {revisados}{" "}
        já revisados por pessoas surdas/linguistas de Libras. O dicionário cresce conforme novos
        sinais são gravados e revisados (veja{" "}
        <a href="/contribuir" className="text-[var(--color-primary)] hover:underline">
          como contribuir
        </a>
        ).
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((sign) => (
          <Card key={sign.id}>
            <SignVideo sign={sign} />
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-semibold">{sign.word}</h3>
              <div className="flex flex-wrap gap-1.5">
                <Badge tone="primary">{sign.category}</Badge>
                <Badge tone={sign.status === "revisado" ? "success" : "warning"}>
                  {sign.status === "revisado" ? "Revisado" : "Em revisão"}
                </Badge>
              </div>
            </div>
            <p className="mt-2 text-sm text-[var(--color-text-muted)]">{sign.description}</p>
            <p className="mt-2 text-sm italic text-[var(--color-text)]">&ldquo;{sign.example}&rdquo;</p>
            <p className="mt-3 text-xs text-[var(--color-text-muted)]">
              {sign.region}
              {sign.updatedAt &&
                ` · atualizado em ${new Date(sign.updatedAt).toLocaleDateString("pt-BR")}`}
            </p>
          </Card>
        ))}
        {filtered.length === 0 && (
          <p className="col-span-full py-10 text-center text-[var(--color-text-muted)]">
            Nenhum sinal encontrado para essa busca.
          </p>
        )}
      </div>

      {visibleCount < filtered.length && (
        <div className="mt-8 flex flex-col items-center gap-2">
          <p className="flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
            <Clock className="h-3.5 w-3.5" aria-hidden="true" />
            Mostrando {visible.length} de {filtered.length}
          </p>
          <Button variant="outline" onClick={() => setVisibleCount((v) => v + PAGE_SIZE)}>
            Carregar mais sinais
          </Button>
        </div>
      )}
    </div>
  );
}

const LEARN_TOPICS = [
  {
    title: "Alfabeto manual",
    description: "Aprenda a soletrar nomes próprios e palavras sem sinal específico.",
  },
  {
    title: "Cumprimentos e apresentação",
    description: "Sinais básicos para se apresentar e cumprimentar alguém.",
  },
  {
    title: "Números e quantidades",
    description: "Como sinalizar números, horas e quantidades no dia a dia.",
  },
  {
    title: "Perguntas essenciais",
    description: "Como perguntar 'o quê', 'onde', 'quando' e 'por quê' em Libras.",
  },
  {
    title: "Estrutura de frases",
    description: "Noções de como a Libras organiza sujeito, verbo e objeto.",
  },
  {
    title: "Expressões não manuais",
    description: "O papel das expressões faciais e corporais na gramática da Libras.",
  },
];

function AprenderLibras() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {LEARN_TOPICS.map((t) => (
        <Card key={t.title}>
          <BookOpen className="h-6 w-6 text-[var(--color-primary)]" aria-hidden="true" />
          <h3 className="mt-3 font-semibold">{t.title}</h3>
          <p className="mt-1 text-sm text-[var(--color-text-muted)]">{t.description}</p>
          <Badge className="mt-3">Conteúdo em desenvolvimento</Badge>
        </Card>
      ))}
    </div>
  );
}

function FrasesUteis() {
  const [copiedIndex, setCopiedIndex] = useState<string | null>(null);

  async function copyPhrase(key: string, phrase: string) {
    try {
      await navigator.clipboard.writeText(phrase);
      setCopiedIndex(key);
      window.setTimeout(() => setCopiedIndex(null), 1800);
    } catch {
      // indisponível
    }
  }

  return (
    <div className="grid gap-6 sm:grid-cols-2">
      {USEFUL_PHRASES.map((group) => (
        <Card key={group.category}>
          <h3 className="font-semibold">{group.category}</h3>
          <ul className="mt-3 flex flex-col gap-2">
            {group.phrases.map((phrase, i) => {
              const key = `${group.category}-${i}`;
              return (
                <li
                  key={key}
                  className="flex items-center justify-between gap-2 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-3 py-2 text-sm"
                >
                  <span>{phrase}</span>
                  <span className="flex shrink-0 gap-1">
                    <button
                      aria-label={`Ouvir: ${phrase}`}
                      onClick={() => speak(phrase)}
                      className="rounded-md p-1.5 hover:bg-[var(--color-bg)]"
                    >
                      <Volume2 className="h-3.5 w-3.5" />
                    </button>
                    <button
                      aria-label={`Copiar: ${phrase}`}
                      onClick={() => copyPhrase(key, phrase)}
                      className="rounded-md p-1.5 hover:bg-[var(--color-bg)]"
                    >
                      {copiedIndex === key ? (
                        <Check className="h-3.5 w-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="h-3.5 w-3.5" />
                      )}
                    </button>
                  </span>
                </li>
              );
            })}
          </ul>
        </Card>
      ))}
    </div>
  );
}

export function LibrasClient() {
  const [tab, setTab] = useState<Tab>("libras-texto");

  return (
    <>
      <PageHeader
        eyebrow="Recursos de Libras"
        title="Libras"
        description="Reconhecimento experimental, tradução Português → Libras, dicionário de sinais, conteúdos para aprender e frases úteis do dia a dia."
      />
      <Container className="py-10 sm:py-14">
        <div
          role="tablist"
          aria-label="Seções de Libras"
          className="flex flex-wrap gap-2 border-b border-[var(--color-border)] pb-4"
        >
          {TABS.map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                tab === t.id
                  ? "bg-[var(--color-primary)] text-[var(--color-primary-contrast)]"
                  : "border border-[var(--color-border)] text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              }`}
            >
              <t.icon className="h-4 w-4" aria-hidden="true" />
              {t.label}
            </button>
          ))}
        </div>

        <div className="mt-8">
          {tab === "libras-texto" && <LibrasParaTexto />}
          {tab === "texto-libras" && <TextoParaLibras />}
          {tab === "dicionario" && <Dicionario />}
          {tab === "aprender" && <AprenderLibras />}
          {tab === "frases" && <FrasesUteis />}
        </div>
      </Container>
    </>
  );
}
