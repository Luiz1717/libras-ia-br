import type { Metadata } from "next";
import { EducacaoClient } from "./EducacaoClient";

export const metadata: Metadata = {
  title: "Educação",
  description:
    "Ferramentas de estudo com IA: resumir textos, explicar conteúdos, gerar perguntas, flashcards e mais.",
};

export default function Page() {
  return <EducacaoClient />;
}
