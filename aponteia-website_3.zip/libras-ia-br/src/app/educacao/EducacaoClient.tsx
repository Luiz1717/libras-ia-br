"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Sparkles,
  FileQuestion,
  Layers,
  Mic,
  Captions,
  ScanText,
  BookMarked,
  CalendarClock,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import {
  mockSummarize,
  mockExplainSimple,
  mockGenerateQuestions,
  mockGenerateFlashcards,
} from "@/lib/ai";

type Action = "resumir" | "explicar" | "perguntas" | "flashcards" | "palavras";

const ACTIONS: { id: Action; label: string; description: string }[] = [
  { id: "resumir", label: "Resumir texto", description: "Reduza um texto aos pontos principais." },
  { id: "explicar", label: "Explicar conteúdo", description: "Reescreva em linguagem mais simples." },
  { id: "perguntas", label: "Criar perguntas", description: "Gere perguntas de estudo sobre o texto." },
  { id: "flashcards", label: "Criar flashcards", description: "Transforme o conteúdo em cartões de estudo." },
  { id: "palavras", label: "Explicar palavras difíceis", description: "Identifique e explique termos complexos." },
];

const SHORTCUTS = [
  { href: "/voz-para-texto", icon: Mic, label: "Transcrever aula" },
  { href: "/legendas", icon: Captions, label: "Gerar legenda" },
  { href: "/ocr", icon: ScanText, label: "Ler documentos" },
];

export function EducacaoClient() {
  const [text, setText] = useState("");
  const [action, setAction] = useState<Action>("resumir");
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState("");
  const [questions, setQuestions] = useState<string[]>([]);
  const [flashcards, setFlashcards] = useState<{ front: string; back: string }[]>([]);
  const [flippedIndex, setFlippedIndex] = useState<number | null>(null);

  async function run() {
    if (!text.trim()) return;
    setLoading(true);
    setSummary("");
    setQuestions([]);
    setFlashcards([]);
    setFlippedIndex(null);

    if (action === "resumir") setSummary(await mockSummarize(text));
    else if (action === "explicar") setSummary(await mockExplainSimple(text));
    else if (action === "palavras")
      setSummary(
        "Termos possivelmente difíceis foram identificados (simulação). Em uma versão conectada a um provedor de IA real, cada termo viria com uma explicação simples ao lado."
      );
    else if (action === "perguntas") setQuestions(await mockGenerateQuestions(text));
    else if (action === "flashcards") setFlashcards(await mockGenerateFlashcards(text));

    setLoading(false);
  }

  return (
    <>
      <PageHeader
        eyebrow="Para estudantes e professores"
        title="Educação"
        description="Recursos de estudo com IA, pensados para estudantes surdos, professores e intérpretes — com linguagem clara, sem infantilizar."
      />
      <Container className="py-10 sm:py-14">
        <div className="mb-8 grid gap-3 sm:grid-cols-3">
          {SHORTCUTS.map((s) => (
            <Link
              key={s.href}
              href={s.href}
              className="flex items-center gap-3 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-4 font-medium hover:border-[var(--color-primary)] hover:text-[var(--color-primary)]"
            >
              <s.icon className="h-5 w-5" aria-hidden="true" />
              {s.label}
            </Link>
          ))}
        </div>

        <Card>
          <label htmlFor="edu-text" className="mb-2 block text-sm font-medium">
            Cole o conteúdo que você quer estudar
          </label>
          <textarea
            id="edu-text"
            rows={7}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Cole aqui um texto, trecho de aula ou artigo…"
            className="w-full resize-y rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-4 leading-relaxed outline-none focus:border-[var(--color-primary)]"
          />

          <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Escolher ação">
            {ACTIONS.map((a) => (
              <button
                key={a.id}
                onClick={() => setAction(a.id)}
                aria-pressed={action === a.id}
                className={`rounded-full border px-3.5 py-1.5 text-sm font-medium ${
                  action === a.id
                    ? "border-[var(--color-primary)] bg-[var(--color-primary)]/10 text-[var(--color-primary)]"
                    : "border-[var(--color-border)] text-[var(--color-text-muted)]"
                }`}
              >
                {a.label}
              </button>
            ))}
          </div>
          <p className="mt-2 text-sm text-[var(--color-text-muted)]">
            {ACTIONS.find((a) => a.id === action)?.description}
          </p>

          <Button className="mt-4" onClick={run} disabled={!text.trim() || loading}>
            <Sparkles className="h-4 w-4" />
            {loading ? "Processando…" : "Gerar"}
          </Button>
        </Card>

        {summary && (
          <Card className="mt-6">
            <h2 className="font-semibold">Resultado</h2>
            <p className="mt-2 leading-relaxed text-[var(--color-text)]">{summary}</p>
          </Card>
        )}

        {questions.length > 0 && (
          <Card className="mt-6">
            <h2 className="flex items-center gap-2 font-semibold">
              <FileQuestion className="h-5 w-5" aria-hidden="true" /> Perguntas de estudo
            </h2>
            <ol className="mt-3 flex flex-col gap-2">
              {questions.map((q, i) => (
                <li
                  key={i}
                  className="rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-4 py-2.5 text-sm"
                >
                  {i + 1}. {q}
                </li>
              ))}
            </ol>
          </Card>
        )}

        {flashcards.length > 0 && (
          <Card className="mt-6">
            <h2 className="flex items-center gap-2 font-semibold">
              <Layers className="h-5 w-5" aria-hidden="true" /> Flashcards
            </h2>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              {flashcards.map((card, i) => (
                <button
                  key={i}
                  onClick={() => setFlippedIndex(flippedIndex === i ? null : i)}
                  className="rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-5 text-left transition-colors hover:border-[var(--color-primary)]"
                >
                  <p className="text-xs font-semibold uppercase text-[var(--color-primary)]">
                    {flippedIndex === i ? "Resposta" : "Pergunta"} · toque para virar
                  </p>
                  <p className="mt-2 font-medium">
                    {flippedIndex === i ? card.back : card.front}
                  </p>
                </button>
              ))}
            </div>
          </Card>
        )}

        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          <Card className="flex items-start gap-3">
            <BookMarked className="h-6 w-6 shrink-0 text-[var(--color-primary)]" aria-hidden="true" />
            <div>
              <h3 className="font-semibold">Organizar estudos</h3>
              <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                Salve resumos e transcrições no seu histórico para revisar depois.
              </p>
            </div>
          </Card>
          <Card className="flex items-start gap-3">
            <CalendarClock className="h-6 w-6 shrink-0 text-[var(--color-primary)]" aria-hidden="true" />
            <div>
              <h3 className="font-semibold">Sem infantilização</h3>
              <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                Nossa linguagem é clara e direta, respeitando estudantes adultos e
                adolescentes.
              </p>
            </div>
          </Card>
        </div>
      </Container>
    </>
  );
}
