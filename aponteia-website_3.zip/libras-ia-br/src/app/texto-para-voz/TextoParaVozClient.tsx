"use client";

import { useEffect, useRef, useState } from "react";
import { Play, Pause, Square, Download, Volume2 } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";

export function TextoParaVozClient() {
  const [text, setText] = useState(
    "Digite ou cole seu texto aqui. Depois, use os controles abaixo para ouvir com a voz e a velocidade que preferir."
  );
  const [rate, setRate] = useState(1);
  const [volume, setVolume] = useState(1);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceIndex, setVoiceIndex] = useState(0);
  const [speaking, setSpeaking] = useState(false);
  const [paused, setPaused] = useState(false);
  const [supported, setSupported] = useState(true);
  const [downloadNote, setDownloadNote] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      // Detecção de suporte do navegador só é possível no cliente.
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setSupported(false);
      return;
    }
    function loadVoices() {
      const all = window.speechSynthesis.getVoices();
      const ptFirst = [...all].sort((a, b) => {
        const aPt = a.lang.toLowerCase().startsWith("pt") ? 0 : 1;
        const bPt = b.lang.toLowerCase().startsWith("pt") ? 0 : 1;
        return aPt - bPt;
      });
      setVoices(ptFirst);
    }
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => {
      window.speechSynthesis.onvoiceschanged = null;
      window.speechSynthesis.cancel();
    };
  }, []);

  const selectedVoice = voices[voiceIndex];

  function handlePlay() {
    if (!supported) return;
    if (paused) {
      window.speechSynthesis.resume();
      setPaused(false);
      setSpeaking(true);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = rate;
    utterance.volume = volume;
    if (selectedVoice) utterance.voice = selectedVoice;
    utterance.lang = selectedVoice?.lang || "pt-BR";
    utterance.onend = () => {
      setSpeaking(false);
      setPaused(false);
    };
    utterance.onerror = () => {
      setSpeaking(false);
      setPaused(false);
    };
    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  }

  function handlePause() {
    window.speechSynthesis.pause();
    setPaused(true);
    setSpeaking(false);
  }

  function handleStop() {
    window.speechSynthesis.cancel();
    setSpeaking(false);
    setPaused(false);
  }

  function handleDownload() {
    setDownloadNote(true);
    window.setTimeout(() => setDownloadNote(false), 4000);
  }

  const charCount = text.length;

  return (
    <>
      <PageHeader
        eyebrow="Ferramenta"
        title="Texto → Voz"
        description="Converta qualquer texto em áudio falado, com controle de velocidade, volume e voz."
      />
      <Container className="py-10 sm:py-14">
        {!supported && (
          <Card className="mb-6 border-amber-500/40 bg-amber-500/10 text-amber-900 dark:text-amber-300">
            Seu navegador não é compatível com síntese de voz. Tente usar o Google Chrome,
            Edge ou Safari atualizados.
          </Card>
        )}

        <Card>
          <label htmlFor="tts-text" className="mb-2 block text-sm font-medium">
            Texto
          </label>
          <textarea
            id="tts-text"
            rows={8}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Digite ou cole seu texto aqui."
            className="w-full resize-y rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-4 text-lg leading-relaxed outline-none focus:border-[var(--color-primary)]"
          />
          <p className="mt-1 text-right text-xs text-[var(--color-text-muted)]">
            {charCount} caracteres
          </p>

          <div className="mt-4 flex flex-wrap gap-3">
            <Button onClick={handlePlay} disabled={!supported || !text.trim()}>
              <Play className="h-4 w-4" /> {paused ? "Continuar" : "Ouvir"}
            </Button>
            <Button variant="outline" onClick={handlePause} disabled={!speaking}>
              <Pause className="h-4 w-4" /> Pausar
            </Button>
            <Button variant="outline" onClick={handleStop} disabled={!speaking && !paused}>
              <Square className="h-4 w-4" /> Parar
            </Button>
            <Button variant="ghost" onClick={handleDownload} disabled={!text.trim()}>
              <Download className="h-4 w-4" /> Baixar áudio
            </Button>
          </div>
          {downloadNote && (
            <p role="status" className="mt-3 rounded-xl bg-[var(--color-bg-subtle)] p-3 text-sm text-[var(--color-text-muted)]">
              A exportação de arquivo de áudio depende de processamento em servidor e ainda
              não está disponível nesta demonstração. Assim que estiver disponível, este
              botão vai gerar um MP3 pronto para baixar.
            </p>
          )}
        </Card>

        <Card className="mt-6 grid gap-6 sm:grid-cols-3">
          <div>
            <label htmlFor="rate" className="mb-2 flex justify-between text-sm font-medium">
              Velocidade <span className="text-[var(--color-text-muted)]">{rate.toFixed(1)}x</span>
            </label>
            <input
              id="rate"
              type="range"
              min={0.5}
              max={2}
              step={0.1}
              value={rate}
              onChange={(e) => setRate(Number(e.target.value))}
              className="w-full accent-[var(--color-primary)]"
            />
          </div>
          <div>
            <label htmlFor="volume" className="mb-2 flex justify-between text-sm font-medium">
              Volume <span className="text-[var(--color-text-muted)]">{Math.round(volume * 100)}%</span>
            </label>
            <input
              id="volume"
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="w-full accent-[var(--color-primary)]"
            />
          </div>
          <div>
            <label htmlFor="voice" className="mb-2 block text-sm font-medium">
              Voz
            </label>
            <div className="relative">
              <Volume2 className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-text-muted)]" />
              <select
                id="voice"
                value={voiceIndex}
                onChange={(e) => setVoiceIndex(Number(e.target.value))}
                className="w-full appearance-none rounded-xl border-2 border-[var(--color-border)] bg-[var(--color-bg-subtle)] py-2.5 pl-9 pr-3 text-sm outline-none focus:border-[var(--color-primary)]"
              >
                {voices.length === 0 && <option>Carregando vozes…</option>}
                {voices.map((v, i) => (
                  <option key={`${v.name}-${i}`} value={i}>
                    {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </Card>
      </Container>
    </>
  );
}
