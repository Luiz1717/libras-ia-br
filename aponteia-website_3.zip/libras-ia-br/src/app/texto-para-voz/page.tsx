import type { Metadata } from "next";
import { TextoParaVozClient } from "./TextoParaVozClient";

export const metadata: Metadata = {
  title: "Texto → Voz",
  description: "Transforme qualquer texto em áudio, com controle de velocidade, volume e voz.",
};

export default function Page() {
  return <TextoParaVozClient />;
}
