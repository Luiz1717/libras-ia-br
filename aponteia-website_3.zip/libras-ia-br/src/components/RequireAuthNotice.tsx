import { LogIn } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/Button";

export function RequireAuthNotice({ title }: { title: string }) {
  return (
    <Container className="flex flex-col items-center gap-4 py-24 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--color-primary)]/10 text-[var(--color-primary)]">
        <LogIn className="h-7 w-7" aria-hidden="true" />
      </span>
      <h1 className="text-2xl font-bold">{title}</h1>
      <p className="max-w-sm text-[var(--color-text-muted)]">
        Entre na sua conta para acessar esta página.
      </p>
      <div className="flex gap-3">
        <ButtonLink href="/entrar">Entrar</ButtonLink>
        <ButtonLink href="/cadastro" variant="outline">
          Criar conta
        </ButtonLink>
      </div>
    </Container>
  );
}
