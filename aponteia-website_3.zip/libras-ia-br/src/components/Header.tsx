"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X, Sparkles, ChevronDown } from "lucide-react";
import clsx from "clsx";
import { useAuth } from "@/lib/auth";

const NAV_LINKS = [
  { href: "/", label: "Início" },
  { href: "/ia", label: "IA" },
  { href: "/libras", label: "Libras" },
  { href: "/legendas", label: "Legendas" },
  { href: "/ferramentas", label: "Ferramentas" },
  { href: "/educacao", label: "Educação" },
  { href: "/sobre", label: "Sobre" },
  { href: "/acessibilidade", label: "Acessibilidade" },
];

export function Header() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    // Fecha os menus abertos sempre que a rota muda.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setOpen(false);
    setUserMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-50 border-b border-[var(--color-border)] bg-[var(--color-bg)]/95 backdrop-blur supports-[backdrop-filter]:bg-[var(--color-bg)]/80">
      <a href="#conteudo-principal" className="skip-link">
        Pular para o conteúdo principal
      </a>
      <div className="mx-auto flex h-16 sm:h-[70px] max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link
          href="/"
          className="flex items-center gap-2 rounded-lg font-bold text-lg text-[var(--color-text)]"
        >
          <span
            className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--color-primary)] text-[var(--color-primary-contrast)]"
            aria-hidden="true"
          >
            <Sparkles className="h-5 w-5" />
          </span>
          <span>
            Aponta<span className="text-[var(--color-primary)]">IA</span>
          </span>
        </Link>

        <nav
          aria-label="Menu principal"
          className="hidden lg:flex items-center gap-1"
        >
          {NAV_LINKS.map((link) => {
            const active =
              link.href === "/" ? pathname === "/" : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                aria-current={active ? "page" : undefined}
                className={clsx(
                  "rounded-full px-3.5 py-2 text-sm font-medium transition-colors",
                  active
                    ? "bg-[var(--color-primary)]/10 text-[var(--color-primary)]"
                    : "text-[var(--color-text-muted)] hover:bg-[var(--color-bg-subtle)] hover:text-[var(--color-text)]"
                )}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden lg:flex items-center gap-2">
          {user ? (
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen((v) => !v)}
                aria-expanded={userMenuOpen}
                aria-haspopup="menu"
                className="flex items-center gap-2 rounded-full border border-[var(--color-border)] py-1.5 pl-1.5 pr-3 text-sm font-medium hover:bg-[var(--color-bg-subtle)]"
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--color-primary)] text-xs font-bold text-[var(--color-primary-contrast)]">
                  {user.name.slice(0, 1).toUpperCase()}
                </span>
                {user.name.split(" ")[0]}
                <ChevronDown className="h-4 w-4" aria-hidden="true" />
              </button>
              {userMenuOpen && (
                <div
                  role="menu"
                  className="absolute right-0 mt-2 w-56 rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)] p-2 shadow-lg"
                >
                  <Link
                    role="menuitem"
                    href="/dashboard"
                    className="block rounded-lg px-3 py-2 text-sm hover:bg-[var(--color-bg-subtle)]"
                  >
                    Painel
                  </Link>
                  <Link
                    role="menuitem"
                    href="/historico"
                    className="block rounded-lg px-3 py-2 text-sm hover:bg-[var(--color-bg-subtle)]"
                  >
                    Histórico
                  </Link>
                  <Link
                    role="menuitem"
                    href="/perfil"
                    className="block rounded-lg px-3 py-2 text-sm hover:bg-[var(--color-bg-subtle)]"
                  >
                    Meu perfil
                  </Link>
                  <button
                    role="menuitem"
                    onClick={logout}
                    className="mt-1 block w-full rounded-lg px-3 py-2 text-left text-sm text-red-600 hover:bg-red-500/10 dark:text-red-400"
                  >
                    Sair
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link
              href="/entrar"
              className="rounded-full bg-[var(--color-primary)] px-5 py-2.5 text-sm font-semibold text-[var(--color-primary-contrast)] hover:bg-[var(--color-primary-hover)]"
            >
              Entrar
            </Link>
          )}
        </div>

        <button
          className="lg:hidden inline-flex h-11 w-11 items-center justify-center rounded-lg border border-[var(--color-border)]"
          aria-expanded={open}
          aria-controls="menu-mobile"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div
          id="menu-mobile"
          className="lg:hidden border-t border-[var(--color-border)] bg-[var(--color-bg)] px-4 pb-6 pt-2"
        >
          <nav aria-label="Menu principal (celular)" className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => {
              const active =
                link.href === "/" ? pathname === "/" : pathname.startsWith(link.href);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  aria-current={active ? "page" : undefined}
                  className={clsx(
                    "rounded-xl px-4 py-3 text-base font-medium",
                    active
                      ? "bg-[var(--color-primary)]/10 text-[var(--color-primary)]"
                      : "text-[var(--color-text)] hover:bg-[var(--color-bg-subtle)]"
                  )}
                >
                  {link.label}
                </Link>
              );
            })}
            <div className="my-2 h-px bg-[var(--color-border)]" />
            {user ? (
              <>
                <Link href="/dashboard" className="rounded-xl px-4 py-3 text-base font-medium hover:bg-[var(--color-bg-subtle)]">
                  Painel
                </Link>
                <Link href="/historico" className="rounded-xl px-4 py-3 text-base font-medium hover:bg-[var(--color-bg-subtle)]">
                  Histórico
                </Link>
                <Link href="/perfil" className="rounded-xl px-4 py-3 text-base font-medium hover:bg-[var(--color-bg-subtle)]">
                  Meu perfil
                </Link>
                <button
                  onClick={logout}
                  className="rounded-xl px-4 py-3 text-left text-base font-medium text-red-600 dark:text-red-400"
                >
                  Sair
                </button>
              </>
            ) : (
              <Link
                href="/entrar"
                className="mt-1 rounded-xl bg-[var(--color-primary)] px-4 py-3 text-center text-base font-semibold text-[var(--color-primary-contrast)]"
              >
                Entrar
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
