import { InputHTMLAttributes } from "react";
import clsx from "clsx";

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  hint?: string;
}

export function Field({ label, error, hint, id, className, ...props }: FieldProps) {
  const errorId = error ? `${id}-error` : undefined;
  const hintId = hint ? `${id}-hint` : undefined;
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium text-[var(--color-text)]">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={!!error}
        aria-describedby={clsx(hintId, errorId) || undefined}
        className={clsx(
          "rounded-xl border-2 bg-[var(--color-bg)] px-4 py-2.5 text-base text-[var(--color-text)] outline-none transition-colors placeholder:text-[var(--color-text-muted)]",
          error
            ? "border-red-500"
            : "border-[var(--color-border)] focus:border-[var(--color-primary)]",
          className
        )}
        {...props}
      />
      {hint && !error && (
        <p id={hintId} className="text-xs text-[var(--color-text-muted)]">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} role="alert" className="text-xs font-medium text-red-600 dark:text-red-400">
          {error}
        </p>
      )}
    </div>
  );
}
