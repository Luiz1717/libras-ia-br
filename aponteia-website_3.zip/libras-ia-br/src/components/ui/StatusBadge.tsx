import clsx from "clsx";
import { CheckCircle2, Loader2, AlertCircle, UploadCloud } from "lucide-react";

export type ProcessState =
  | "idle"
  | "enviando"
  | "processando"
  | "analisando"
  | "concluido"
  | "erro";

const CONFIG: Record<
  ProcessState,
  { label: string; icon: React.ElementType; tone: string; spin?: boolean }
> = {
  idle: { label: "Pronto", icon: CheckCircle2, tone: "text-[var(--color-text-muted)]" },
  enviando: { label: "Enviando…", icon: UploadCloud, tone: "text-[var(--color-primary)]", spin: false },
  processando: { label: "Processando…", icon: Loader2, tone: "text-[var(--color-primary)]", spin: true },
  analisando: { label: "Analisando áudio…", icon: Loader2, tone: "text-[var(--color-primary)]", spin: true },
  concluido: { label: "Concluído", icon: CheckCircle2, tone: "text-emerald-600 dark:text-emerald-400" },
  erro: { label: "Não foi possível processar. Tente novamente.", icon: AlertCircle, tone: "text-red-600 dark:text-red-400" },
};

export function StatusBadge({ state, label }: { state: ProcessState; label?: string }) {
  const cfg = CONFIG[state];
  const Icon = cfg.icon;
  return (
    <span
      role="status"
      aria-live="polite"
      className={clsx(
        "inline-flex items-center gap-2 rounded-full border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-4 py-2 text-sm font-medium",
        cfg.tone
      )}
    >
      <Icon className={clsx("h-4 w-4", cfg.spin && "animate-spin")} aria-hidden="true" />
      {label ?? cfg.label}
    </span>
  );
}
