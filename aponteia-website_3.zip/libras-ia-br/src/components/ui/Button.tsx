import { ButtonHTMLAttributes, forwardRef } from "react";
import Link from "next/link";
import clsx from "clsx";

type Variant = "primary" | "secondary" | "outline" | "ghost" | "danger";
type Size = "sm" | "md" | "lg";

const VARIANT_CLASSES: Record<Variant, string> = {
  primary:
    "bg-[var(--color-primary)] text-[var(--color-primary-contrast)] hover:bg-[var(--color-primary-hover)] shadow-sm",
  secondary:
    "bg-[var(--color-accent)] text-[var(--color-accent-contrast)] hover:opacity-90 shadow-sm",
  outline:
    "border-2 border-[var(--color-primary)] text-[var(--color-primary)] hover:bg-[var(--color-primary)]/10 bg-transparent",
  ghost:
    "text-[var(--color-text)] hover:bg-[var(--color-bg-subtle)] bg-transparent",
  danger: "bg-red-600 text-white hover:bg-red-700",
};

const SIZE_CLASSES: Record<Size, string> = {
  sm: "text-sm px-3 py-2 gap-1.5",
  md: "text-base px-5 py-3 gap-2",
  lg: "text-lg px-7 py-4 gap-2.5",
};

interface BaseProps {
  variant?: Variant;
  size?: Size;
  fullWidth?: boolean;
}

type ButtonProps = BaseProps &
  ButtonHTMLAttributes<HTMLButtonElement> & { href?: undefined };

type LinkProps = BaseProps & {
  href: string;
  children: React.ReactNode;
  className?: string;
  target?: string;
  rel?: string;
  "aria-label"?: string;
};

const baseClasses =
  "inline-flex items-center justify-center whitespace-nowrap rounded-full font-semibold transition-colors duration-[var(--motion-duration)] focus-visible:outline-3 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer";

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", size = "md", fullWidth, className, ...props }, ref) => (
    <button
      ref={ref}
      className={clsx(
        baseClasses,
        VARIANT_CLASSES[variant],
        SIZE_CLASSES[size],
        fullWidth && "w-full",
        className
      )}
      {...props}
    />
  )
);
Button.displayName = "Button";

export function ButtonLink({
  variant = "primary",
  size = "md",
  fullWidth,
  className,
  href,
  ...props
}: LinkProps) {
  return (
    <Link
      href={href}
      className={clsx(
        baseClasses,
        VARIANT_CLASSES[variant],
        SIZE_CLASSES[size],
        fullWidth && "w-full",
        className
      )}
      {...props}
    />
  );
}
