import { Container } from "./Container";

export function PageHeader({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="border-b border-[var(--color-border)] bg-[var(--color-bg-subtle)] py-12 sm:py-16">
      <Container>
        {eyebrow && (
          <p className="mb-2 text-sm font-semibold uppercase tracking-wide text-[var(--color-primary)]">
            {eyebrow}
          </p>
        )}
        <h1 className="text-3xl font-bold tracking-tight text-[var(--color-text)] sm:text-4xl">
          {title}
        </h1>
        {description && (
          <p className="mt-4 max-w-2xl text-lg text-[var(--color-text-muted)]">
            {description}
          </p>
        )}
        {children}
      </Container>
    </div>
  );
}

export function ExperimentalNotice({ children }: { children: React.ReactNode }) {
  return (
    <div
      role="note"
      className="flex items-start gap-3 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-sm text-amber-900 dark:text-amber-300"
    >
      <span aria-hidden="true" className="mt-0.5 text-lg">⚠️</span>
      <p>{children}</p>
    </div>
  );
}
