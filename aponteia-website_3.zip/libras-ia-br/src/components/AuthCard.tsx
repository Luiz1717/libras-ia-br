import Link from "next/link";
import { Container } from "@/components/ui/Container";
import { Card } from "@/components/ui/Card";

export function AuthCard({
  title,
  description,
  children,
  footer,
}: {
  title: string;
  description: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
}) {
  return (
    <div className="bg-[var(--color-bg-subtle)] py-14 sm:py-20">
      <Container className="max-w-md">
        <Card className="shadow-sm">
          <h1 className="text-2xl font-bold">{title}</h1>
          <p className="mt-1.5 text-[var(--color-text-muted)]">{description}</p>
          <div className="mt-6">{children}</div>
        </Card>
        {footer && <p className="mt-6 text-center text-sm text-[var(--color-text-muted)]">{footer}</p>}
        <p className="mt-4 text-center text-xs text-[var(--color-text-muted)]">
          <Link href="/" className="hover:text-[var(--color-primary)] hover:underline">
            Voltar para o início
          </Link>
        </p>
      </Container>
    </div>
  );
}

export function ProviderButtons({ onSelect }: { onSelect: (p: "google" | "apple") => void }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <button
        type="button"
        onClick={() => onSelect("google")}
        className="flex items-center justify-center gap-2 rounded-full border border-[var(--color-border)] py-2.5 text-sm font-medium hover:bg-[var(--color-bg-subtle)]"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
          <path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.2-2.27H12v4.51h6.47c-.28 1.48-1.13 2.73-2.4 3.58v2.98h3.88c2.27-2.09 3.54-5.17 3.54-8.8z" />
          <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.94-2.92l-3.88-2.98c-1.08.72-2.45 1.15-4.06 1.15-3.12 0-5.77-2.11-6.71-4.95H1.29v3.09C3.26 21.3 7.31 24 12 24z" />
          <path fill="#FBBC05" d="M5.29 14.3A7.19 7.19 0 0 1 4.9 12c0-.8.14-1.57.38-2.3V6.61H1.29A11.98 11.98 0 0 0 0 12c0 1.93.46 3.76 1.29 5.39z" />
          <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.44-3.44C17.94 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.61l4 3.09C6.23 6.86 8.88 4.75 12 4.75z" />
        </svg>
        Google
      </button>
      <button
        type="button"
        onClick={() => onSelect("apple")}
        className="flex items-center justify-center gap-2 rounded-full border border-[var(--color-border)] py-2.5 text-sm font-medium hover:bg-[var(--color-bg-subtle)]"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current" aria-hidden="true">
          <path d="M16.365 1.43c0 1.14-.47 2.24-1.23 3.05-.83.9-2.16 1.6-3.27 1.51-.14-1.1.44-2.28 1.19-3.05.84-.87 2.28-1.53 3.31-1.51zm3.6 16.66c-.48 1.09-.7 1.58-1.31 2.55-.85 1.35-2.05 3.04-3.53 3.06-1.32.02-1.66-.85-3.45-.84-1.79.01-2.16.86-3.48.84-1.48-.02-2.62-1.53-3.47-2.88-2.39-3.79-2.64-8.24-1.17-10.61.98-1.62 2.55-2.57 4.03-2.57 1.5 0 2.44.85 3.68.85 1.2 0 1.93-.85 3.65-.85 1.32 0 2.72.72 3.72 1.96-3.27 1.79-2.74 6.45.33 8.49z" />
        </svg>
        Apple
      </button>
    </div>
  );
}
