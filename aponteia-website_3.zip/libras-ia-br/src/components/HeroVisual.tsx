export function HeroVisual() {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-md" aria-hidden="true">
      <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-to-br from-[var(--color-primary)]/15 to-[var(--color-accent)]/15" />
      <svg viewBox="0 0 400 400" className="relative h-full w-full">
        <circle cx="200" cy="200" r="150" fill="var(--color-primary)" fillOpacity="0.08" />
        <circle cx="200" cy="200" r="105" fill="var(--color-primary)" fillOpacity="0.08" />

        {/* speech bubble - ouvinte */}
        <g transform="translate(52,88)">
          <rect width="128" height="82" rx="20" fill="var(--color-surface)" stroke="var(--color-border)" strokeWidth="2" />
          <path d="M28 170 L28 130 L68 130 Z" fill="var(--color-surface)" stroke="var(--color-border)" strokeWidth="2" />
          <circle cx="30" cy="35" r="9" fill="var(--color-primary)" />
          <rect x="50" y="27" width="58" height="8" rx="4" fill="var(--color-border)" />
          <rect x="50" y="47" width="42" height="8" rx="4" fill="var(--color-border)" />
        </g>

        {/* hand / libras shape - pessoa surda */}
        <g transform="translate(220,86)">
          <rect width="128" height="82" rx="20" fill="var(--color-accent)" fillOpacity="0.12" stroke="var(--color-accent)" strokeWidth="2" />
          <path d="M100 170 L100 130 L60 130 Z" fill="var(--color-accent)" fillOpacity="0.12" stroke="var(--color-accent)" strokeWidth="2" />
          <path
            d="M40 55c-4 0-7 3-7 7v22c0 12 10 22 22 22s22-10 22-22v-10"
            fill="none"
            stroke="var(--color-accent)"
            strokeWidth="6"
            strokeLinecap="round"
          />
          <path d="M47 62v-16" stroke="var(--color-accent)" strokeWidth="6" strokeLinecap="round" />
          <path d="M60 62v-16" stroke="var(--color-accent)" strokeWidth="6" strokeLinecap="round" />
          <path d="M73 62v13" stroke="var(--color-accent)" strokeWidth="6" strokeLinecap="round" />
        </g>

        {/* central AI node */}
        <g transform="translate(200,255)">
          <circle r="36" fill="var(--color-primary)" />
          <path d="M0 -16v32M-16 0h32" stroke="var(--color-primary-contrast)" strokeWidth="6" strokeLinecap="round" />
          <circle r="8" fill="var(--color-accent)" cx="30" cy="-30" />
        </g>

        <path d="M116 170 L184 240" stroke="var(--color-border)" strokeWidth="2" strokeDasharray="6 6" />
        <path d="M284 170 L216 240" stroke="var(--color-border)" strokeWidth="2" strokeDasharray="6 6" />
      </svg>
    </div>
  );
}
