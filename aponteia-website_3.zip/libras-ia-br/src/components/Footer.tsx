import Link from "next/link";
import { Sparkles } from "lucide-react";
import { Container } from "./ui/Container";

const COLUMNS = [
  {
    title: "Ferramentas",
    links: [
      { href: "/voz-para-texto", label: "Fala → Texto" },
      { href: "/texto-para-voz", label: "Texto → Voz" },
      { href: "/legendas", label: "Vídeo → Legenda" },
      { href: "/ocr", label: "Imagem → Texto" },
      { href: "/libras", label: "Libras" },
    ],
  },
  {
    title: "Plataforma",
    links: [
      { href: "/ia", label: "Assistente IA" },
      { href: "/educacao", label: "Educação" },
      { href: "/acessibilidade", label: "Acessibilidade" },
      { href: "/contribuir", label: "Faça parte do projeto" },
    ],
  },
  {
    title: "Institucional",
    links: [
      { href: "/sobre", label: "Sobre o projeto" },
      { href: "/privacidade", label: "Privacidade" },
      { href: "/contribuir", label: "Contato" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-[var(--color-border)] bg-[var(--color-bg-subtle)]">
      <Container className="py-12">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2 font-bold text-lg">
              <span
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--color-primary)] text-[var(--color-primary-contrast)]"
                aria-hidden="true"
              >
                <Sparkles className="h-4 w-4" />
              </span>
              Aponta<span className="text-[var(--color-primary)]">IA</span>
            </div>
            <p className="mt-3 max-w-xs text-sm text-[var(--color-text-muted)]">
              Tecnologia que aproxima pessoas. Inteligência artificial que amplia a
              acessibilidade — criada com a comunidade surda brasileira.
            </p>
          </div>
          {COLUMNS.map((col) => (
            <nav key={col.title} aria-label={col.title}>
              <h2 className="text-sm font-semibold text-[var(--color-text)]">
                {col.title}
              </h2>
              <ul className="mt-3 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      className="text-sm text-[var(--color-text-muted)] hover:text-[var(--color-primary)]"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>
        <div className="mt-10 flex flex-col-reverse items-start gap-4 border-t border-[var(--color-border)] pt-6 text-sm text-[var(--color-text-muted)] sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} AponteIA. Projeto de tecnologia assistiva brasileiro.</p>
          <p className="max-w-md">
            Libras é uma língua natural com gramática própria. Nossas ferramentas de IA
            para Libras são experimentais e não substituem intérpretes humanos.
          </p>
        </div>
      </Container>
    </footer>
  );
}
